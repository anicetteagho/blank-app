/*! SYCAM V223 — sycam-v223-stories-status.js
 * Stories / statut sur Accueil :
 *  - Cercle profil + liste stories
 *  - Création texte / image (compressée)
 *  - Visionneuse plein écran
 *  - Expiration 24h
 * Local-first (localStorage)
 */
(function (global) {
  "use strict";

  var VERSION = "223.0.0-stories-status";
  var STORIES_KEY = "sycam_stories_v223";
  var AVATAR_KEY = "sycam_story_avatar_v223";
  var TTL_MS = 24 * 60 * 60 * 1000;

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }
  function load(key, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(key) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {
      toast("Stockage plein — image trop lourde");
    }
  }

  function now() {
    return Date.now();
  }

  function getStories() {
    var list = load(STORIES_KEY, []);
    var t = now();
    list = list.filter(function (s) {
      return s.expiresAt > t;
    });
    save(STORIES_KEY, list);
    return list;
  }

  function getAvatar() {
    var a = load(AVATAR_KEY, null);
    if (a) return a;
    try {
      var p =
        global.SycamV222 && global.SycamV222.getProfile
          ? global.SycamV222.getProfile()
          : null;
      if (p && p.name) return { letter: p.name.charAt(0).toUpperCase(), dataUrl: null };
    } catch (e) {}
    return { letter: "S", dataUrl: null };
  }

  function setAvatarDataUrl(dataUrl) {
    var cur = getAvatar();
    save(AVATAR_KEY, { letter: cur.letter || "S", dataUrl: dataUrl });
  }

  function compressImage(file, maxW, quality) {
    maxW = maxW || 720;
    quality = quality || 0.72;
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = function () {
        reject(new Error("read"));
      };
      reader.onload = function () {
        var img = new Image();
        img.onload = function () {
          var w = img.width;
          var h = img.height;
          if (w > maxW) {
            h = Math.round((h * maxW) / w);
            w = maxW;
          }
          var canvas = document.createElement("canvas");
          canvas.width = w;
          canvas.height = h;
          var ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL("image/jpeg", quality));
        };
        img.onerror = function () {
          reject(new Error("img"));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function addStory(partial) {
    var list = getStories();
    var item = {
      id: "st_" + Date.now().toString(36),
      type: partial.type || "text",
      text: partial.text || "",
      image: partial.image || null,
      createdAt: now(),
      expiresAt: now() + TTL_MS,
      author: (getAvatar().letter || "S") + " · Moi"
    };
    list.unshift(item);
    save(STORIES_KEY, list.slice(0, 30));
    return item;
  }

  function ensureStyles() {
    if ($("sycam-v223-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v223-css";
    s.textContent = [
      ".v223-stories{display:flex;gap:12px;overflow-x:auto;padding:8px 2px 14px;margin:0 0 8px;-webkit-overflow-scrolling:touch}",
      ".v223-stories::-webkit-scrollbar{display:none}",
      ".v223-ring{flex:0 0 auto;width:72px;text-align:center;cursor:pointer;background:transparent;border:0;color:#e2e8f0;padding:0}",
      ".v223-ring .circle{width:64px;height:64px;border-radius:50%;margin:0 auto 6px;padding:3px;background:linear-gradient(135deg,#0d7377,#2dd4bf,#38bdf8);box-sizing:border-box}",
      ".v223-ring .circle.muted{background:#334155}",
      ".v223-ring .inner{width:100%;height:100%;border-radius:50%;background:#0b1220;display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative;font-weight:800;font-size:20px;color:#fff}",
      ".v223-ring .inner img{width:100%;height:100%;object-fit:cover}",
      ".v223-ring .plus{position:absolute;right:0;bottom:0;width:22px;height:22px;border-radius:50%;background:#2563eb;color:#fff;font-size:16px;line-height:22px;border:2px solid #0b1220}",
      ".v223-ring .lbl{font-size:10px;font-weight:700;color:#94a3b8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:72px}",
      "#v223Viewer{position:fixed;inset:0;z-index:200;background:#000;display:none;flex-direction:column}",
      "#v223Viewer.on{display:flex}",
      "#v223Viewer .top{display:flex;align-items:center;gap:10px;padding:calc(10px + env(safe-area-inset-top,0px)) 12px 8px;color:#fff}",
      "#v223Viewer .progress{display:flex;gap:3px;padding:0 12px 8px}",
      "#v223Viewer .progress i{flex:1;height:3px;border-radius:2px;background:rgba(255,255,255,.25)}",
      "#v223Viewer .progress i.on{background:#fff}",
      "#v223Viewer .body{flex:1;display:flex;align-items:center;justify-content:center;padding:12px;position:relative}",
      "#v223Viewer .body img{max-width:100%;max-height:100%;object-fit:contain}",
      "#v223Viewer .body .txt{font-size:22px;font-weight:700;color:#fff;text-align:center;line-height:1.35;padding:24px}",
      "#v223Viewer .close{border:0;background:rgba(255,255,255,.15);color:#fff;width:40px;height:40px;border-radius:50%;font-size:18px;cursor:pointer}",
      "#pg-story-create{padding:16px;padding-bottom:100px;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;max-width:720px;margin:0 auto}",
      "#pg-story-create.on{display:block}",
      "#pg-story-create h1{margin:0 0 8px;font-size:20px;color:#fff}",
      "#pg-story-create textarea{width:100%;min-height:120px;box-sizing:border-box;padding:12px;border-radius:12px;border:1px solid #1f2937;background:#030712;color:#e2e8f0;font-size:15px}",
      "#pg-story-create .actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}",
      "#pg-story-create button{border:0;border-radius:10px;padding:12px 14px;font-weight:700;cursor:pointer;background:#1f2937;color:#e2e8f0;min-height:44px}",
      "#pg-story-create button.primary{background:#0d7377;color:#fff}"
    ].join("");
    document.head.appendChild(s);
  }

  function renderStoriesBar(container) {
    if (!container) return;
    ensureStyles();
    var stories = getStories();
    var av = getAvatar();
    var html =
      '<button type="button" class="v223-ring" id="v223AddStory">' +
      '<div class="circle"><div class="inner">' +
      (av.dataUrl
        ? '<img src="' + esc(av.dataUrl) + '" alt=""/>'
        : esc(av.letter || "S")) +
      '<span class="plus">+</span></div></div>' +
      '<div class="lbl">Votre story</div></button>';

    // group by author simple — show each story
    stories.slice(0, 12).forEach(function (st, idx) {
      html +=
        '<button type="button" class="v223-ring" data-story-idx="' +
        idx +
        '">' +
        '<div class="circle"><div class="inner">' +
        (st.image
          ? '<img src="' + esc(st.image) + '" alt=""/>'
          : esc((st.text || "?").charAt(0).toUpperCase())) +
        "</div></div>" +
        '<div class="lbl">' +
        esc((st.author || "Story").split("·")[0].trim().slice(0, 10)) +
        "</div></button>";
    });

    container.innerHTML = html;
    container.className = "v223-stories";

    var add = container.querySelector("#v223AddStory");
    if (add) add.onclick = function () {
      openCreate();
    };
    container.querySelectorAll("[data-story-idx]").forEach(function (b) {
      b.onclick = function () {
        openViewer(parseInt(b.getAttribute("data-story-idx"), 10) || 0);
      };
    });
  }

  function injectIntoHome() {
    var home = $("pg-mobilehome");
    if (!home || home.style.display === "none") return;
    var existing = $("v223StoriesBar");
    if (!existing) {
      existing = document.createElement("div");
      existing.id = "v223StoriesBar";
      var sub = home.querySelector(".v219-sub");
      if (sub && sub.parentNode) {
        sub.parentNode.insertBefore(existing, sub.nextSibling);
      } else {
        home.insertBefore(existing, home.firstChild);
      }
    }
    renderStoriesBar(existing);
  }

  function openCreate() {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $("pg-story-create");
    if (!page) {
      page = document.createElement("section");
      page.id = "pg-story-create";
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    page.innerHTML =
      "<h1>Nouvelle story</h1>" +
      '<p style="font-size:12px;color:#94a3b8">Visible 24 h · stockage local</p>' +
      '<textarea id="v223Text" placeholder="Écrivez un statut…"></textarea>' +
      '<div class="actions">' +
      '<label class="primary" style="display:inline-block;padding:12px 14px;border-radius:10px;background:#0d7377;color:#fff;font-weight:700;cursor:pointer">Photo<input type="file" id="v223Img" accept="image/*" style="display:none"/></label>' +
      '<button type="button" class="primary" id="v223Pub">Publier</button>' +
      '<button type="button" id="v223Av">Photo de profil</button>' +
      '<button type="button" id="v223Cancel">Annuler</button>' +
      "</div>" +
      '<div id="v223Prev" style="margin-top:12px"></div>';

    var pendingImage = null;
    $("v223Img").onchange = function () {
      var f = $("v223Img").files && $("v223Img").files[0];
      if (!f) return;
      compressImage(f).then(function (url) {
        pendingImage = url;
        $("v223Prev").innerHTML = '<img src="' + url + '" style="max-width:100%;border-radius:12px"/>';
      });
    };
    $("v223Av").onclick = function () {
      var inp = document.createElement("input");
      inp.type = "file";
      inp.accept = "image/*";
      inp.onchange = function () {
        var f = inp.files && inp.files[0];
        if (!f) return;
        compressImage(f, 256, 0.8).then(function (url) {
          setAvatarDataUrl(url);
          toast("Photo de profil mise à jour");
          injectIntoHome();
        });
      };
      inp.click();
    };
    $("v223Pub").onclick = function () {
      var text = ($("v223Text").value || "").trim();
      if (!text && !pendingImage) {
        toast("Ajoutez un texte ou une photo");
        return;
      }
      addStory({
        type: pendingImage ? "image" : "text",
        text: text,
        image: pendingImage
      });
      toast("Story publiée");
      if (global.SycamV219 && global.SycamV219.openMobileHome) {
        global.SycamV219.openMobileHome();
        setTimeout(injectIntoHome, 80);
      } else {
        injectIntoHome();
      }
    };
    $("v223Cancel").onclick = function () {
      if (global.SycamV219 && global.SycamV219.openMobileHome) global.SycamV219.openMobileHome();
    };
  }

  var viewerTimer = null;
  var viewerIdx = 0;

  function ensureViewer() {
    if ($("v223Viewer")) return $("v223Viewer");
    var el = document.createElement("div");
    el.id = "v223Viewer";
    el.innerHTML =
      '<div class="top"><button type="button" class="close" id="v223Close">✕</button><span id="v223VAuthor" style="font-weight:700"></span></div>' +
      '<div class="progress" id="v223Prog"></div>' +
      '<div class="body" id="v223Body"></div>';
    document.body.appendChild(el);
    $("v223Close").onclick = closeViewer;
    el.addEventListener("click", function (e) {
      if (e.target.id === "v223Body" || e.target.closest("#v223Body")) {
        var stories = getStories();
        if (viewerIdx + 1 < stories.length) openViewer(viewerIdx + 1);
        else closeViewer();
      }
    });
    document.addEventListener("keydown", function (e) {
      if (!$("v223Viewer") || !$("v223Viewer").classList.contains("on")) return;
      if (e.key === "Escape") closeViewer();
      if (e.key === "ArrowRight") openViewer(viewerIdx + 1);
      if (e.key === "ArrowLeft") openViewer(Math.max(0, viewerIdx - 1));
    });
    return el;
  }

  function openViewer(idx) {
    ensureStyles();
    var stories = getStories();
    if (!stories.length) {
      toast("Aucune story active");
      return;
    }
    if (idx >= stories.length) {
      closeViewer();
      return;
    }
    viewerIdx = idx;
    var st = stories[idx];
    var v = ensureViewer();
    v.classList.add("on");
    $("v223VAuthor").textContent = st.author || "Story";
    var prog = $("v223Prog");
    prog.innerHTML = stories
      .map(function (_, i) {
        return "<i class='" + (i <= idx ? "on" : "") + "'></i>";
      })
      .join("");
    var body = $("v223Body");
    if (st.image) {
      body.innerHTML = '<img src="' + esc(st.image) + '" alt="story"/>';
    } else {
      body.innerHTML = '<div class="txt">' + esc(st.text || "") + "</div>";
    }
    clearTimeout(viewerTimer);
    viewerTimer = setTimeout(function () {
      if (idx + 1 < stories.length) openViewer(idx + 1);
      else closeViewer();
    }, 5000);
  }

  function closeViewer() {
    clearTimeout(viewerTimer);
    var v = $("v223Viewer");
    if (v) v.classList.remove("on");
  }

  function patchHome() {
    if (!global.SycamV219 || !global.SycamV219.openMobileHome || global.SycamV219.__stories223)
      return;
    var orig = global.SycamV219.openMobileHome.bind(global.SycamV219);
    global.SycamV219.openMobileHome = function () {
      orig();
      setTimeout(injectIntoHome, 60);
    };
    global.SycamV219.__stories223 = true;
  }

  function boot() {
    ensureStyles();
    patchHome();
    setTimeout(patchHome, 400);
    setTimeout(injectIntoHome, 600);

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v223"] = {
        id: "sycam-v223",
        version: VERSION,
        global: "SycamV223",
        requires: ["sycam-v222"],
        provides: ["stories.bar", "stories.viewer", "stories.create"],
        modifies: ["SycamV219.openMobileHome"],
        routes: ["stories", "status"],
        storage: [STORIES_KEY, AVATAR_KEY],
        events: [],
        permissions: ["stories.local"],
        adr: ["ADR-025"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV223 = ["SycamV222"];
    }
    if (typeof global.go === "function" && !global.__sycamV223Go) {
      global.__sycamV223Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "stories" || n === "status") {
          openCreate();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V223] Stories", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV223 = {
    version: VERSION,
    getStories: getStories,
    addStory: addStory,
    openCreate: openCreate,
    openViewer: openViewer,
    injectIntoHome: injectIntoHome,
    setAvatarDataUrl: setAvatarDataUrl
  };
})(typeof window !== "undefined" ? window : this);
