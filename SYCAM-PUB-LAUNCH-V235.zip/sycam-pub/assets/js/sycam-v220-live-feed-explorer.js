/*! SYCAM V220 — sycam-v220-live-feed-explorer.js
 * Fil Accueil live (ressources + HAL + notes)
 * Explorer recherche NEXUS / HAL
 */
(function (global) {
  "use strict";

  var VERSION = "220.0.0-live-feed-explorer";
  var FEED_CACHE = "sycam_feed_cache_v220";
  var FILTER_KEY = "sycam_feed_filter_v220";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }
  function load(key, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(key) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
  }

  function fromResources() {
    var items = [];
    try {
      var list =
        global.SycamV210 && global.SycamV210.listResources
          ? global.SycamV210.listResources()
          : [];
      list.forEach(function (r) {
        items.push({
          id: r.id || "res_" + Math.random().toString(36).slice(2),
          kind: r.type === "publication" ? "pub" : r.source === "hal" ? "news" : "pub",
          tag: r.source === "hal" ? "HAL" : r.type === "note" ? "Note" : "Pub",
          title: r.title || "Sans titre",
          meta: (r.source || "sycam") + " · " + (r.createdAt || r.updatedAt || "").slice(0, 10),
          excerpt: JSON.stringify(r.meta || {}).slice(0, 140),
          url: r.url || "",
          raw: r
        });
      });
    } catch (e) {}
    return items;
  }

  function fromBridgeNotes() {
    var items = [];
    try {
      var notes = load("sycam_bridge_notes_v211", []);
      notes.forEach(function (n) {
        items.push({
          id: n.id || "note_" + Math.random().toString(36).slice(2),
          kind: "pub",
          tag: "Note",
          title: n.title || "Note",
          meta: "bridge · " + (n.at || "").slice(0, 10),
          excerpt: String(n.body || "").slice(0, 140),
          url: "",
          raw: n
        });
      });
    } catch (e) {}
    return items;
  }

  async function fromHal(q) {
    q = q || "Cameroun science";
    var items = [];
    try {
      if (global.SycamV202 && global.SycamV202.searchHal) {
        var pack = await global.SycamV202.searchHal(q, "", 8);
        (pack.docs || []).forEach(function (d) {
          items.push({
            id: "hal_" + (d.halId || d.uri || Math.random().toString(36).slice(2)),
            kind: "news",
            tag: "HAL",
            title: d.title || "Document HAL",
            meta: "HAL · " + (d.producedDate || d.uri || "").toString().slice(0, 24),
            excerpt: (d.abstract || d.citationFull || "").toString().slice(0, 160),
            url: d.uri || d.fileMain || "",
            raw: d
          });
        });
      } else if (global.SycamV201 && global.SycamV201.searchHal) {
        var pack2 = await global.SycamV201.searchHal(q);
        var docs = (pack2 && pack2.docs) || pack2 || [];
        if (Array.isArray(docs)) {
          docs.slice(0, 8).forEach(function (d, i) {
            items.push({
              id: "hal2_" + i,
              kind: "news",
              tag: "HAL",
              title: d.title || d.label || "HAL",
              meta: "HAL",
              excerpt: String(d.abstract || d.uri || "").slice(0, 140),
              url: d.uri || "",
              raw: d
            });
          });
        }
      } else if (global.SycamV210 && global.SycamV210.execute) {
        var r = await global.SycamV210.execute("hal.search", { q: q }, { skipLegal: true });
        var res = (r && r.data && (r.data.resources || r.data.docs)) || [];
        if (Array.isArray(res)) {
          res.slice(0, 8).forEach(function (d, i) {
            items.push({
              id: "halx_" + i,
              kind: "news",
              tag: "HAL",
              title: d.title || "HAL",
              meta: "NEXUS · HAL",
              excerpt: String((d.meta && d.meta.abstract) || d.url || "").slice(0, 140),
              url: d.url || "",
              raw: d
            });
          });
        }
      }
    } catch (e) {
      console.warn("[V220] HAL", e);
    }
    return items;
  }

  async function buildFeed(opts) {
    opts = opts || {};
    var local = fromResources().concat(fromBridgeNotes());
    var remote = [];
    if (opts.withHal !== false) {
      remote = await fromHal(opts.q || "Afrique recherche");
    }
    var all = local.concat(remote);
    // dedupe by title
    var seen = {};
    all = all.filter(function (x) {
      var k = (x.title || "").toLowerCase();
      if (seen[k]) return false;
      seen[k] = 1;
      return true;
    });
    save(FEED_CACHE, { at: new Date().toISOString(), items: all.slice(0, 60) });
    return all;
  }

  function filterItems(items, filter) {
    filter = filter || "tous";
    if (filter === "pub") return items.filter(function (i) {
      return i.kind === "pub" || i.tag === "Pub" || i.tag === "Note";
    });
    if (filter === "news") return items.filter(function (i) {
      return i.kind === "news" || i.tag === "HAL" || i.tag === "News";
    });
    return items;
  }

  function renderCard(item) {
    return (
      '<article class="v219-feed-card" data-id="' +
      esc(item.id) +
      '">' +
      '<span class="tag">' +
      esc(item.tag) +
      "</span>" +
      "<h4>" +
      esc(item.title) +
      "</h4>" +
      '<div class="meta">' +
      esc(item.meta) +
      "</div>" +
      '<div class="excerpt">' +
      esc(item.excerpt || "") +
      "</div>" +
      (item.url
        ? '<div style="margin-top:8px"><a href="' +
          esc(item.url) +
          '" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0d7377">Ouvrir</a></div>'
        : "") +
      "</article>"
    );
  }

  function ensureStyles() {
    if ($("sycam-v220-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v220-css";
    s.textContent = [
      "#pg-explorer-v220{padding:12px 14px 100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none}",
      "#pg-explorer-v220.on{display:block}",
      "#pg-explorer-v220 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v220-empty{padding:24px;text-align:center;color:#94a3b8;font-size:13px}",
      ".v220-loading{padding:16px;color:#2dd4bf;font-size:13px}"
    ].join("");
    document.head.appendChild(s);
  }

  function showPage(id) {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  async function refreshHomeFeed(filter) {
    filter = filter || load(FILTER_KEY, "tous");
    save(FILTER_KEY, filter);
    var box = $("v219Feed") || $("v220Feed");
    if (!box) return;
    box.innerHTML = '<div class="v220-loading">Chargement du fil…</div>';
    var items = await buildFeed({ withHal: true });
    items = filterItems(items, filter);
    if (!items.length) {
      box.innerHTML =
        '<div class="v220-empty">Aucune entrée.<br/>Publiez un document ou lancez une recherche HAL.</div>';
      return items;
    }
    box.innerHTML = items.slice(0, 30).map(renderCard).join("");
    return items;
  }

  function patchMobileHome() {
    if (!global.SycamV219 || !global.SycamV219.openMobileHome || global.SycamV219.__feed220) return;
    var orig = global.SycamV219.openMobileHome.bind(global.SycamV219);
    global.SycamV219.openMobileHome = function () {
      orig();
      setTimeout(function () {
        var filter = load(FILTER_KEY, "tous");
        document.querySelectorAll("#pg-mobilehome .v219-chip").forEach(function (c) {
          c.classList.toggle("on", c.getAttribute("data-f") === filter);
          c.onclick = function () {
            document.querySelectorAll("#pg-mobilehome .v219-chip").forEach(function (x) {
              x.classList.remove("on");
            });
            c.classList.add("on");
            refreshHomeFeed(c.getAttribute("data-f"));
          };
        });
        var search = $("v219Search");
        if (search) {
          search.onkeydown = function (ev) {
            if (ev.key === "Enter") {
              openExplorer(search.value || "");
            }
          };
        }
        // ensure feed container id
        var feed = $("v219Feed");
        if (feed && !feed.id) feed.id = "v220Feed";
        refreshHomeFeed(filter);
      }, 50);
    };
    global.SycamV219.__feed220 = true;
  }

  var searchTimer = null;

  async function runSearch(q) {
    q = String(q || "").trim();
    var out = $("v220Results");
    if (!out) return;
    out.innerHTML = '<div class="v220-loading">Recherche…</div>';
    var items = [];
    if (q.length >= 2) {
      items = await fromHal(q);
      // also filter local
      var local = fromResources().concat(fromBridgeNotes()).filter(function (i) {
        return (i.title + i.excerpt).toLowerCase().indexOf(q.toLowerCase()) !== -1;
      });
      items = local.concat(items);
    } else {
      items = await buildFeed({ withHal: true, q: "science" });
    }
    if (!items.length) {
      out.innerHTML = '<div class="v220-empty">Aucun résultat pour « ' + esc(q) + " »</div>";
      return;
    }
    out.innerHTML = items.slice(0, 40).map(renderCard).join("");
  }

  function openExplorer(initialQ) {
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    var page = showPage("pg-explorer-v220");
    page.innerHTML =
      "<h1>Explorer</h1>" +
      '<p class="v219-sub" style="color:#94a3b8;font-size:12px">Recherche NEXUS · HAL · ressources locales</p>' +
      '<input class="v219-search" id="v220Q" type="search" placeholder="Auteur, mot-clé, titre…" value="' +
      esc(initialQ || "") +
      '"/>' +
      '<div class="v219-chip-row" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">' +
      '<button type="button" class="v219-chip on" data-sq="Cameroun">Cameroun</button>' +
      '<button type="button" class="v219-chip" data-sq="énergie">Énergie</button>' +
      '<button type="button" class="v219-chip" data-sq="agriculture">Agriculture</button>' +
      '<button type="button" class="v219-chip" data-sq="santé">Santé</button>' +
      "</div>" +
      '<div id="v220Results"><div class="v220-loading">…</div></div>';

    var input = $("v220Q");
    function schedule() {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(function () {
        runSearch(input.value);
      }, 300);
    }
    input.oninput = schedule;
    input.onkeydown = function (ev) {
      if (ev.key === "Enter") {
        clearTimeout(searchTimer);
        runSearch(input.value);
      }
    };
    page.querySelectorAll("[data-sq]").forEach(function (b) {
      b.onclick = function () {
        input.value = b.getAttribute("data-sq");
        page.querySelectorAll("[data-sq]").forEach(function (x) {
          x.classList.remove("on");
        });
        b.classList.add("on");
        runSearch(input.value);
      };
    });
    runSearch(initialQ || "Cameroun");
  }

  // Hook bottom nav Explorer from V219
  function patchNavExplorer() {
    document.addEventListener(
      "click",
      function (e) {
        var b = e.target && e.target.closest && e.target.closest(".sycam-v219-bottom-nav [data-nav='explorer']");
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        openExplorer("");
      },
      true
    );
  }

  function boot() {
    patchMobileHome();
    patchNavExplorer();
    setTimeout(patchMobileHome, 400);

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v220"] = {
        id: "sycam-v220",
        version: VERSION,
        global: "SycamV220",
        requires: ["sycam-v219"],
        provides: ["feed.live", "explorer.search"],
        modifies: ["SycamV219.openMobileHome"],
        routes: ["explorer", "feed"],
        storage: [FEED_CACHE, FILTER_KEY],
        events: [],
        permissions: ["feed.read"],
        adr: ["ADR-022"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV220 = ["SycamV219"];
    }
    if (global.SycamV192 && global.SycamV192.ALIAS) {
      global.SycamV192.ALIAS.explorer = "explorer";
      global.SycamV192.ALIAS.feed = "feed";
    }

    if (typeof global.go === "function" && !global.__sycamV220Go) {
      global.__sycamV220Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "explorer" || n === "feed") {
          openExplorer("");
          return;
        }
        return orig.apply(this, arguments);
      };
    }

    console.log("[V220] Live feed + explorer", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV220 = {
    version: VERSION,
    buildFeed: buildFeed,
    refreshHomeFeed: refreshHomeFeed,
    openExplorer: openExplorer,
    fromHal: fromHal
  };
})(typeof window !== "undefined" ? window : this);
