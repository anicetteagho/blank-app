/*! SYCAM V227 — sycam-v227-pwa-register.js
 * Enregistrement Service Worker + install PWA
 */
(function (global) {
  "use strict";

  var VERSION = "227.0.0-pwa-shell";
  var deferredPrompt = null;

  function $(id) {
    return document.getElementById(id);
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
  }

  function isStandalone() {
    return (
      (global.matchMedia && global.matchMedia("(display-mode: standalone)").matches) ||
      global.navigator.standalone === true
    );
  }

  function registerSW() {
    if (!("serviceWorker" in navigator)) {
      console.warn("[V227] SW non supporté");
      return Promise.resolve(null);
    }
    // relative to page
    var swUrl = "sw.js";
    return navigator.serviceWorker
      .register(swUrl)
      .then(function (reg) {
        console.log("[V227] SW registered", reg.scope);
        if (reg.waiting) {
          reg.waiting.postMessage({ type: "SKIP_WAITING" });
        }
        reg.addEventListener("updatefound", function () {
          var w = reg.installing;
          if (!w) return;
          w.addEventListener("statechange", function () {
            if (w.state === "installed" && navigator.serviceWorker.controller) {
              toast("Mise à jour PWA disponible — rechargez");
              if (global.SycamV224 && global.SycamV224.pushNotif) {
                global.SycamV224.pushNotif({
                  title: "Mise à jour disponible",
                  body: "Rechargez pour activer le shell V227",
                  action: "home"
                });
              }
            }
          });
        });
        return reg;
      })
      .catch(function (err) {
        console.warn("[V227] SW register fail", err);
        return null;
      });
  }

  function ensureInstallBanner() {
    if (isStandalone()) return;
    if ($("v227Install")) return;
    var bar = document.createElement("div");
    bar.id = "v227Install";
    bar.style.cssText =
      "display:none;position:fixed;left:12px;right:12px;bottom:calc(72px + env(safe-area-inset-bottom,0px));z-index:70;" +
      "background:#111827;border:1px solid #0d7377;border-radius:14px;padding:12px 14px;color:#e2e8f0;" +
      "box-shadow:0 8px 24px rgba(0,0,0,.35);font-size:13px";
    bar.innerHTML =
      '<div style="font-weight:800;margin-bottom:4px">Installer SYCAM-PUB</div>' +
      '<div style="color:#94a3b8;margin-bottom:10px;font-size:12px">Accès écran d’accueil · mode application</div>' +
      '<div style="display:flex;gap:8px">' +
      '<button type="button" id="v227InstallBtn" style="border:0;border-radius:10px;padding:10px 14px;background:#0d7377;color:#fff;font-weight:700;cursor:pointer">Installer</button>' +
      '<button type="button" id="v227InstallDismiss" style="border:0;border-radius:10px;padding:10px 14px;background:#1f2937;color:#e2e8f0;font-weight:700;cursor:pointer">Plus tard</button>' +
      "</div>";
    document.body.appendChild(bar);
    $("v227InstallDismiss").onclick = function () {
      bar.style.display = "none";
      try {
        sessionStorage.setItem("sycam_v227_dismiss", "1");
      } catch (e) {}
    };
    $("v227InstallBtn").onclick = function () {
      if (!deferredPrompt) {
        toast("Utilisez le menu navigateur → Ajouter à l’écran d’accueil");
        return;
      }
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(function () {
        deferredPrompt = null;
        bar.style.display = "none";
      });
    };
  }

  function showInstallIfReady() {
    try {
      if (sessionStorage.getItem("sycam_v227_dismiss")) return;
    } catch (e) {}
    if (isStandalone() || !deferredPrompt) return;
    ensureInstallBanner();
    var bar = $("v227Install");
    if (bar) bar.style.display = "block";
  }

  function openPwaStatus() {
    var pageId = "pg-pwa-v227";
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(pageId);
    if (!page) {
      page = document.createElement("section");
      page.id = pageId;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    var swState = "non supporté";
    if ("serviceWorker" in navigator) {
      swState = navigator.serviceWorker.controller ? "actif" : "enregistré / en attente";
    }
    page.innerHTML =
      '<div style="padding:16px;max-width:720px;margin:0 auto;color:#e2e8f0">' +
      "<h1 style=\"color:#fff;font-size:20px\">PWA · Shell</h1>" +
      '<p style="font-size:12px;color:#94a3b8">V227 · standalone · cache shell</p>' +
      '<div style="background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;margin:12px 0">' +
      "<div>Mode standalone : <b>" +
      (isStandalone() ? "oui" : "non") +
      "</b></div>" +
      "<div style=\"margin-top:8px\">Service Worker : <b>" +
      swState +
      "</b></div>" +
      "<div style=\"margin-top:8px\">Install prompt : <b>" +
      (deferredPrompt ? "disponible" : "non") +
      "</b></div></div>" +
      '<button type="button" id="v227Back" style="border:0;border-radius:10px;padding:12px 14px;background:#0d7377;color:#fff;font-weight:700">Accueil</button>' +
      "</div>";
    $("v227Back").onclick = function () {
      if (global.SycamV219) global.SycamV219.openMobileHome();
    };
  }

  function boot() {
    registerSW();
    global.addEventListener("beforeinstallprompt", function (e) {
      e.preventDefault();
      deferredPrompt = e;
      showInstallIfReady();
    });
    global.addEventListener("appinstalled", function () {
      deferredPrompt = null;
      toast("SYCAM-PUB installé");
      var bar = $("v227Install");
      if (bar) bar.style.display = "none";
      if (global.SycamV224 && global.SycamV224.pushNotif) {
        global.SycamV224.pushNotif({
          title: "Application installée",
          body: "SYCAM-PUB est sur votre écran d’accueil",
          action: "home"
        });
      }
    });

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v227"] = {
        id: "sycam-v227",
        version: VERSION,
        global: "SycamV227",
        requires: ["sycam-v226"],
        provides: ["pwa.shell", "pwa.install"],
        modifies: [],
        routes: ["pwa"],
        storage: [],
        events: ["beforeinstallprompt", "appinstalled"],
        permissions: ["pwa"],
        adr: ["ADR-029"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV227 = ["SycamV226"];
    }
    if (typeof global.go === "function" && !global.__sycamV227Go) {
      global.__sycamV227Go = true;
      var orig = global.go;
      global.go = function (name) {
        if (String(name || "").toLowerCase() === "pwa") {
          openPwaStatus();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V227] PWA", VERSION, "standalone=", isStandalone());
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV227 = {
    version: VERSION,
    registerSW: registerSW,
    isStandalone: isStandalone,
    openPwaStatus: openPwaStatus
  };
})(typeof window !== "undefined" ? window : this);
