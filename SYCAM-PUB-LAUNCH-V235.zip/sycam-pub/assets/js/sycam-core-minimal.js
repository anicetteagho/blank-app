/*! SYCAM core minimal — Resource Bus + Legal léger pour stack V219–V230 */
(function (global) {
  "use strict";
  var RES_KEY = "sycam_resources_v210";
  var MANDATE_KEY = "sycam_mandate_v212";

  function load(k, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(k) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {}
  }

  function listResources() {
    return load(RES_KEY, []);
  }
  function putResource(r) {
    var list = listResources();
    var item = Object.assign(
      {
        id: "r_" + Date.now().toString(36),
        createdAt: new Date().toISOString(),
        type: "document",
        title: "Sans titre",
        source: "sycam",
        meta: {},
        capabilities: ["read"]
      },
      r || {}
    );
    list.unshift(item);
    save(RES_KEY, list.slice(0, 200));
    return item;
  }

  global.SycamV210 = {
    version: "210-minimal",
    listResources: listResources,
    putResource: putResource,
    execute: function (action, payload) {
      payload = payload || {};
      if (action === "publication.create") {
        var res = putResource({
          type: "publication",
          title: payload.title || "Publication",
          source: "sycam",
          meta: payload,
          capabilities: ["read", "preview"]
        });
        return Promise.resolve({ ok: true, data: res });
      }
      if (action === "hal.search") {
        return Promise.resolve({ ok: true, data: { resources: [], docs: [] } });
      }
      return Promise.resolve({ ok: true, data: null });
    },
    openNexusSoftware: function () {
      if (global.SycamV219) global.SycamV219.openMissionControl();
    }
  };

  function getMandate() {
    return load(MANDATE_KEY, { accepted: false });
  }
  global.SycamV212 = {
    version: "212-minimal",
    getMandate: getMandate,
    openLegal: function () {
      var ok = global.confirm(
        "SYCAM-PUB — Mandat local\n\n" +
          "Les actions de publication et d'import restent sur cet appareil.\n" +
          "Vous validez explicitement les écritures sensibles.\n\n" +
          "Accepter le mandat ?"
      );
      if (ok) {
        save(MANDATE_KEY, { accepted: true, at: new Date().toISOString() });
        if (global.showToast) global.showToast("Mandat accepté");
      }
    },
    requestAction: function (opts) {
      opts = opts || {};
      if (!getMandate().accepted && opts.forceConfirm !== false) {
        return { approved: false, reason: "MANDATE_REQUIRED" };
      }
      if (opts.forceConfirm) {
        var a = global.confirm((opts.description || opts.action || "Action") + "\n\nConfirmer ?");
        return { approved: !!a, reason: a ? "OK" : "USER_REFUSED" };
      }
      return { approved: true, reason: "OK" };
    }
  };

  global.showToast = global.showToast || function (msg) {
    var t = document.getElementById("toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "toast";
      t.style.cssText =
        "position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#111827;color:#fff;padding:10px 16px;border-radius:10px;font-size:13px;z-index:999;opacity:0;transition:opacity .2s";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.opacity = "1";
    t.classList.add("on");
    setTimeout(function () {
      t.style.opacity = "0";
      t.classList.remove("on");
    }, 2200);
  };

  global.go = global.go || function (name) {
    name = String(name || "").toLowerCase();
    if (name === "home" || name === "accueil") {
      if (global.SycamV219) global.SycamV219.openMobileHome();
    }
  };

  console.log("[CORE] minimal ready");
})(typeof window !== "undefined" ? window : this);
