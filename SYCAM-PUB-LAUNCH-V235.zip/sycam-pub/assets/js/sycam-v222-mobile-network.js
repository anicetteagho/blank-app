/*! SYCAM V222 — sycam-v222-mobile-network.js
 * Réseau mobile : Tout | IB | Groupes
 * Annuaire local · messages · profil minimal · lien file V218
 */
(function (global) {
  "use strict";

  var VERSION = "222.0.0-mobile-network";
  var MEMBERS_KEY = "sycam_network_members_v222";
  var MSGS_KEY = "sycam_network_msgs_v222";
  var PROFILE_KEY = "sycam_network_profile_v222";
  var TAB_KEY = "sycam_network_tab_v222";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }
  function load(key, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(key) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
  }
  function uid(p) {
    return (p || "id") + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function defaultMembers() {
    return [
      {
        id: "m_anicet",
        name: "Anicet Anicet",
        title: "Chercheur · SYCAM",
        dept: "Innovation",
        avatar: "A",
        friend: true
      },
      {
        id: "m_demo1",
        name: "Dr. Marie K.",
        title: "Biotech",
        dept: "Sciences",
        avatar: "M",
        friend: true
      },
      {
        id: "m_demo2",
        name: "Paul N.",
        title: "Étudiant",
        dept: "Génie",
        avatar: "P",
        friend: false
      },
      {
        id: "m_demo3",
        name: "Labo Énergie",
        title: "Groupe",
        dept: "Communauté",
        avatar: "L",
        friend: false,
        isGroup: true
      }
    ];
  }

  function getMembers() {
    var m = load(MEMBERS_KEY, null);
    if (!m || !m.length) {
      m = defaultMembers();
      save(MEMBERS_KEY, m);
    }
    return m;
  }

  function getProfile() {
    return load(PROFILE_KEY, {
      name: "Dr. SYCAM",
      title: "Membre SYCAM-PUB",
      bio: "Science · Innovation · Impact",
      avatar: "S"
    });
  }

  function getMsgs(peerId) {
    var all = load(MSGS_KEY, {});
    return all[peerId] || [];
  }

  function pushMsg(peerId, text, fromMe) {
    var all = load(MSGS_KEY, {});
    if (!all[peerId]) all[peerId] = [];
    all[peerId].push({
      id: uid("msg"),
      text: text,
      fromMe: !!fromMe,
      at: new Date().toISOString()
    });
    if (all[peerId].length > 200) all[peerId] = all[peerId].slice(-200);
    save(MSGS_KEY, all);
    // mirror to file queue outbox if available
    if (fromMe && global.SycamV218 && global.SycamV218.enqueueOutbox) {
      try {
        global.SycamV218.enqueueOutbox({
          type: "note",
          title: "Msg → " + peerId,
          body: text,
          source: "network",
          requiresApproval: false,
          meta: { peerId: peerId }
        });
      } catch (e) {}
    }
  }

  function ensureStyles() {
    if ($("sycam-v222-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v222-css";
    s.textContent = [
      "#pg-network-v222{padding:12px 14px 100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}",
      "#pg-network-v222.on{display:block}",
      "#pg-network-v222 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v222-sub{font-size:12px;color:#94a3b8;margin:0 0 12px}",
      ".v222-tabs{display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap}",
      ".v222-tabs button{border:0;border-radius:999px;padding:8px 14px;font-size:12px;font-weight:700;background:#1f2937;color:#e2e8f0;cursor:pointer;min-height:36px}",
      ".v222-tabs button.on{background:#0d7377;color:#fff}",
      ".v222-search{width:100%;box-sizing:border-box;padding:11px 14px;border-radius:999px;border:1px solid #1f2937;background:#030712;color:#e2e8f0;font-size:14px;min-height:44px;margin-bottom:12px}",
      ".v222-member{display:flex;align-items:center;gap:12px;padding:12px;background:#111827;border:1px solid #1f2937;border-radius:14px;margin-bottom:8px;cursor:pointer}",
      ".v222-av{width:44px;height:44px;border-radius:50%;background:#0d7377;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;flex-shrink:0}",
      ".v222-member .name{font-size:14px;font-weight:700;color:#fff}",
      ".v222-member .meta{font-size:11px;color:#94a3b8}",
      ".v222-chat{display:flex;flex-direction:column;gap:8px;max-height:50vh;overflow-y:auto;margin:12px 0;padding:8px}",
      ".v222-bubble{max-width:85%;padding:10px 12px;border-radius:14px;font-size:13px;line-height:1.35}",
      ".v222-bubble.me{align-self:flex-end;background:#0d7377;color:#fff;border-bottom-right-radius:4px}",
      ".v222-bubble.them{align-self:flex-start;background:#1f2937;color:#e2e8f0;border-bottom-left-radius:4px}",
      ".v222-compose{display:flex;gap:8px;align-items:center}",
      ".v222-compose input{flex:1;padding:11px 12px;border-radius:999px;border:1px solid #1f2937;background:#030712;color:#e2e8f0;min-height:44px}",
      ".v222-compose button{border:0;border-radius:999px;padding:11px 16px;background:#0d7377;color:#fff;font-weight:700;min-height:44px;cursor:pointer}",
      ".v222-card{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;margin-bottom:12px}",
      ".v222-actions button{border:0;border-radius:10px;padding:10px 12px;font-weight:700;font-size:12px;cursor:pointer;background:#1f2937;color:#e2e8f0;margin:4px 4px 0 0;min-height:40px}",
      ".v222-actions button.primary{background:#0d7377;color:#fff}"
    ].join("");
    document.head.appendChild(s);
  }

  function showPage(id) {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  var view = "list"; // list | chat | profile
  var activePeer = null;
  var tab = "all";

  function openNetwork(opts) {
    opts = opts || {};
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    if (opts.tab) tab = opts.tab;
    else tab = load(TAB_KEY, "all");
    view = opts.view || "list";
    if (opts.peerId) {
      activePeer = opts.peerId;
      view = "chat";
    }
    render();
  }

  function render() {
    save(TAB_KEY, tab);
    var page = showPage("pg-network-v222");
    if (view === "chat" && activePeer) return renderChat(page);
    if (view === "profile") return renderProfile(page);
    renderList(page);
  }

  function renderList(page) {
    var members = getMembers();
    var q = "";
    var filtered = members.filter(function (m) {
      if (tab === "ib") return !!m.friend && !m.isGroup;
      if (tab === "groupes") return !!m.isGroup;
      return true;
    });

    page.innerHTML =
      "<h1>Réseau</h1>" +
      '<p class="v222-sub">Membres · messages locaux · groupes</p>' +
      '<div class="v222-tabs">' +
      '<button type="button" class="' +
      (tab === "all" ? "on" : "") +
      '" data-tab="all">Tout</button>' +
      '<button type="button" class="' +
      (tab === "ib" ? "on" : "") +
      '" data-tab="ib">IB</button>' +
      '<button type="button" class="' +
      (tab === "groupes" ? "on" : "") +
      '" data-tab="groupes">Groupes</button>' +
      '<button type="button" data-tab="profile">Mon profil</button>' +
      "</div>" +
      '<input class="v222-search" id="v222Search" placeholder="Chercher un membre…" type="search"/>' +
      '<div id="v222List"></div>' +
      '<div class="v222-actions">' +
      '<button type="button" class="primary" id="v222Add">+ Contact démo</button>' +
      '<button type="button" id="v222Queue">File locale</button>' +
      "</div>";

    function paintList(query) {
      query = (query || "").toLowerCase();
      var list = filtered.filter(function (m) {
        if (!query) return true;
        return (m.name + m.title + m.dept).toLowerCase().indexOf(query) !== -1;
      });
      var box = $("v222List");
      if (!list.length) {
        box.innerHTML =
          '<div style="padding:20px;text-align:center;color:#94a3b8;font-size:13px">Aucun membre</div>';
        return;
      }
      box.innerHTML = list
        .map(function (m) {
          return (
            '<div class="v222-member" data-peer="' +
            esc(m.id) +
            '"><div class="v222-av">' +
            esc(m.avatar || m.name.charAt(0)) +
            '</div><div><div class="name">' +
            esc(m.name) +
            '</div><div class="meta">' +
            esc(m.title) +
            " · " +
            esc(m.dept) +
            (m.friend ? " · IB" : "") +
            "</div></div></div>"
          );
        })
        .join("");
      box.querySelectorAll("[data-peer]").forEach(function (el) {
        el.onclick = function () {
          activePeer = el.getAttribute("data-peer");
          view = "chat";
          render();
        };
      });
    }

    paintList("");
    $("v222Search").oninput = function () {
      paintList($("v222Search").value);
    };
    page.querySelectorAll("[data-tab]").forEach(function (b) {
      b.onclick = function () {
        var t = b.getAttribute("data-tab");
        if (t === "profile") {
          view = "profile";
          render();
          return;
        }
        tab = t;
        view = "list";
        render();
      };
    });
    $("v222Add").onclick = function () {
      var m = getMembers();
      m.push({
        id: uid("m"),
        name: "Membre " + (m.length + 1),
        title: "Collaborateur",
        dept: "SYCAM",
        avatar: String(m.length + 1),
        friend: true
      });
      save(MEMBERS_KEY, m);
      toast("Contact ajouté");
      render();
    };
    $("v222Queue").onclick = function () {
      if (global.SycamV218) global.SycamV218.openQueue();
      else toast("File V218 absente");
    };
  }

  function renderChat(page) {
    var members = getMembers();
    var peer = members.filter(function (m) {
      return m.id === activePeer;
    })[0] || { id: activePeer, name: activePeer, avatar: "?" };
    var msgs = getMsgs(activePeer);

    page.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">' +
      '<button type="button" id="v222Back" style="border:0;background:#1f2937;color:#fff;border-radius:10px;width:40px;height:40px;cursor:pointer">←</button>' +
      '<div class="v222-av">' +
      esc(peer.avatar || "?") +
      "</div><div><div style=\"font-weight:800;color:#fff\">" +
      esc(peer.name) +
      '</div><div style="font-size:11px;color:#94a3b8">' +
      esc(peer.title || "") +
      "</div></div></div>" +
      '<div class="v222-chat" id="v222Chat"></div>' +
      '<div class="v222-compose"><input id="v222Msg" placeholder="Message…" enterkeyhint="send"/><button type="button" id="v222Send">Envoyer</button></div>';

    var chat = $("v222Chat");
    chat.innerHTML = msgs.length
      ? msgs
          .map(function (m) {
            return (
              '<div class="v222-bubble ' +
              (m.fromMe ? "me" : "them") +
              '">' +
              esc(m.text) +
              "</div>"
            );
          })
          .join("")
      : '<div style="text-align:center;color:#94a3b8;font-size:12px;padding:20px">Aucun message — dites bonjour</div>';
    chat.scrollTop = chat.scrollHeight;

    $("v222Back").onclick = function () {
      view = "list";
      activePeer = null;
      render();
    };
    function send() {
      var text = ($("v222Msg").value || "").trim();
      if (!text) return;
      pushMsg(activePeer, text, true);
      $("v222Msg").value = "";
      render();
    }
    $("v222Send").onclick = send;
    $("v222Msg").onkeydown = function (ev) {
      if (ev.key === "Enter") send();
    };
  }

  function renderProfile(page) {
    var p = getProfile();
    page.innerHTML =
      "<h1>Mon profil</h1>" +
      '<p class="v222-sub">Identité locale SYCAM-PUB</p>' +
      '<div class="v222-card" style="text-align:center">' +
      '<div class="v222-av" style="width:64px;height:64px;margin:0 auto 10px;font-size:22px">' +
      esc(p.avatar || "S") +
      "</div>" +
      '<div class="v222-field"><label style="font-size:11px;color:#94a3b8">Nom</label>' +
      '<input id="v222PName" value="' +
      esc(p.name) +
      '" style="width:100%;box-sizing:border-box;padding:10px;border-radius:10px;border:1px solid #1f2937;background:#030712;color:#fff;margin:6px 0"/></div>' +
      '<div class="v222-field"><label style="font-size:11px;color:#94a3b8">Titre</label>' +
      '<input id="v222PTitle" value="' +
      esc(p.title) +
      '" style="width:100%;box-sizing:border-box;padding:10px;border-radius:10px;border:1px solid #1f2937;background:#030712;color:#fff;margin:6px 0"/></div>' +
      '<div class="v222-field"><label style="font-size:11px;color:#94a3b8">Bio</label>' +
      '<textarea id="v222PBio" rows="3" style="width:100%;box-sizing:border-box;padding:10px;border-radius:10px;border:1px solid #1f2937;background:#030712;color:#fff;margin:6px 0">' +
      esc(p.bio) +
      "</textarea></div></div>" +
      '<div class="v222-actions">' +
      '<button type="button" class="primary" id="v222SaveP">Enregistrer</button>' +
      '<button type="button" id="v222BackList">Retour réseau</button>' +
      "</div>";

    $("v222SaveP").onclick = function () {
      save(PROFILE_KEY, {
        name: $("v222PName").value,
        title: $("v222PTitle").value,
        bio: $("v222PBio").value,
        avatar: ( $("v222PName").value || "S").charAt(0).toUpperCase()
      });
      toast("Profil enregistré");
    };
    $("v222BackList").onclick = function () {
      view = "list";
      render();
    };
  }

  function patchNav() {
    document.addEventListener(
      "click",
      function (e) {
        var b =
          e.target &&
          e.target.closest &&
          e.target.closest(".sycam-v219-bottom-nav [data-nav='reseau']");
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        openNetwork({ view: "list" });
      },
      true
    );
  }

  function boot() {
    patchNav();
    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v222"] = {
        id: "sycam-v222",
        version: VERSION,
        global: "SycamV222",
        requires: ["sycam-v221"],
        provides: ["network.mobile", "network.chat", "network.profile"],
        modifies: [],
        routes: ["reseau", "network", "messages"],
        storage: [MEMBERS_KEY, MSGS_KEY, PROFILE_KEY, TAB_KEY],
        events: [],
        permissions: ["network.local"],
        adr: ["ADR-024"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV222 = ["SycamV221"];
    }
    if (global.SycamV192 && global.SycamV192.ALIAS) {
      global.SycamV192.ALIAS.reseau = "reseau";
      global.SycamV192.ALIAS.network = "reseau";
      global.SycamV192.ALIAS.messages = "reseau";
    }
    if (typeof global.go === "function" && !global.__sycamV222Go) {
      global.__sycamV222Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "reseau" || n === "network" || n === "messages") {
          openNetwork({});
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V222] Mobile network", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV222 = {
    version: VERSION,
    openNetwork: openNetwork,
    getMembers: getMembers,
    getProfile: getProfile
  };
})(typeof window !== "undefined" ? window : this);
