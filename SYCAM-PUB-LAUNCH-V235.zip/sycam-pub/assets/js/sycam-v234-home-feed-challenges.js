/*! SYCAM V234 — Accueil enrichi : Fil réseau + Actualités + Challenges + Partenaires */
(function (global) {
  "use strict";

  var VERSION = "234.0.0-home-feed-challenges";
  var CH_KEY = "sycam_challenges_v234";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function defaultChallenges() {
    return [
      {
        id: "ch1",
        badge: "hybride",
        title: "Innovation énergétique Cameroun 2026",
        org: "SYCAM-PUB",
        excerpt: "Proposez un protocole ou un dataset sur l'énergie accessible. Publiez et collaborez.",
        tags: ["Énergie", "Dataset", "Open science"],
        status: "open",
        days: 18,
        mode: "en cours"
      },
      {
        id: "ch2",
        badge: "en ligne",
        title: "Hackathon données agricoles",
        org: "Réseau SYCAM",
        excerpt: "Créez un jeu de données ou un article court sur l'agriculture et le climat.",
        tags: ["Agriculture", "HAL", "Publication"],
        status: "open",
        days: 7,
        mode: "en cours"
      },
      {
        id: "ch3",
        badge: "présentiel",
        title: "Visibilité des thèses africaines",
        org: "Bibliotech SYCAM",
        excerpt: "Déposez ou indexez une thèse / mémoire et gagnez en visibilité institutionnelle.",
        tags: ["Thèses", "Bibliothèque"],
        status: "upcoming",
        days: 30,
        mode: "à venir"
      },
      {
        id: "ch4",
        badge: "terminé",
        title: "Sprint rédaction scientifique",
        org: "JARVIS Lab",
        excerpt: "Challenge passé — consultez les publications associées dans le fil.",
        tags: ["Rédaction", "Article"],
        status: "done",
        days: 0,
        mode: "terminé"
      }
    ];
  }

  function getChallenges() {
    try {
      var v = JSON.parse(localStorage.getItem(CH_KEY) || "null");
      if (v && v.length) return v;
    } catch (e) {}
    var d = defaultChallenges();
    try {
      localStorage.setItem(CH_KEY, JSON.stringify(d));
    } catch (e) {}
    return d;
  }

  function ensureStyles() {
    if ($("sycam-v234-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v234-css";
    s.textContent = [
      ".v234-greet{margin:4px 0 12px}",
      ".v234-greet h2{margin:0;font-size:18px;color:#fff;font-weight:800}",
      ".v234-greet p{margin:4px 0 0;font-size:12px;color:#94a3b8}",
      ".v234-kpis{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0 0 14px}",
      "@media(min-width:480px){.v234-kpis{grid-template-columns:repeat(4,1fr)}}",
      ".v234-kpi{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:12px;text-align:left}",
      ".v234-kpi .n{font-size:22px;font-weight:800;color:#fff}",
      ".v234-kpi .l{font-size:10px;color:#94a3b8;margin-top:4px}",
      ".v234-tabs{display:flex;gap:6px;overflow-x:auto;margin:0 0 10px;padding-bottom:4px}",
      ".v234-tabs button{border:0;border-radius:999px;padding:8px 12px;font-size:12px;font-weight:700;background:#1f2937;color:#94a3b8;white-space:nowrap;cursor:pointer}",
      ".v234-tabs button.on{background:#0d7377;color:#fff}",
      ".v234-chips{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 12px}",
      ".v234-chips button{border:1px solid #1f2937;border-radius:999px;padding:6px 12px;font-size:11px;font-weight:700;background:#0b1220;color:#cbd5e1;cursor:pointer}",
      ".v234-chips button.on{border-color:#0d7377;color:#2dd4bf}",
      ".v234-ch{background:#111827;border:1px solid #1f2937;border-radius:16px;padding:14px;margin:0 0 10px}",
      ".v234-ch .badges{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}",
      ".v234-ch .bdg{font-size:10px;font-weight:800;padding:3px 8px;border-radius:6px;background:#1f2937;color:#94a3b8}",
      ".v234-ch .bdg.open{background:#0f2a2c;color:#2dd4bf}",
      ".v234-ch h4{margin:0 0 6px;font-size:15px;color:#fff;line-height:1.3}",
      ".v234-ch .ex{font-size:12px;color:#94a3b8;line-height:1.4;margin:0 0 8px}",
      ".v234-ch .tags{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px}",
      ".v234-ch .tag{font-size:10px;padding:3px 8px;border-radius:999px;background:#1e293b;color:#cbd5e1}",
      ".v234-ch .meta{font-size:11px;color:#64748b;margin-bottom:10px}",
      ".v234-ch .acts{display:flex;gap:8px;flex-wrap:wrap}",
      ".v234-ch .acts button{border:0;border-radius:10px;padding:10px 12px;font-size:12px;font-weight:700;cursor:pointer;min-height:40px}",
      ".v234-ch .acts .p{background:#0d7377;color:#fff}",
      ".v234-ch .acts .g{background:#1f2937;color:#e2e8f0}",
      ".v234-partners{display:flex;gap:10px;overflow-x:auto;padding-bottom:8px}",
      ".v234-partner{flex:0 0 140px;background:#111827;border:1px solid #1f2937;border-radius:14px;padding:12px;text-align:center}",
      ".v234-partner .av{width:48px;height:48px;border-radius:50%;background:#0d7377;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;margin:0 auto 8px}",
      ".v234-partner .nm{font-size:12px;font-weight:700;color:#fff}",
      ".v234-partner .rl{font-size:10px;color:#94a3b8;margin-top:4px}",
      ".v234-feed-item{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:12px;margin:0 0 8px}",
      ".v234-feed-item .who{font-size:12px;font-weight:700;color:#2dd4bf}",
      ".v234-feed-item .tx{font-size:13px;color:#e2e8f0;margin-top:4px}",
      ".v234-feed-item .tm{font-size:10px;color:#64748b;margin-top:6px}",
      ".v234-news-mini{background:#fff;color:#0f172a;border-radius:14px;padding:12px;margin:0 0 8px}",
      ".v234-news-mini h4{margin:4px 0;font-size:14px}",
      ".v234-news-mini .m{font-size:11px;color:#64748b}",
      ".v234-sec{font-size:13px;font-weight:800;color:#2dd4bf;margin:16px 0 8px;display:flex;justify-content:space-between;align-items:center}",
      ".v234-sec button{border:0;background:transparent;color:#94a3b8;font-size:11px;font-weight:700;cursor:pointer}"
    ].join("");
    document.head.appendChild(s);
  }

  function profileName() {
    try {
      if (global.SycamV222 && global.SycamV222.getProfile) {
        return global.SycamV222.getProfile().name || "chercheur";
      }
    } catch (e) {}
    return "chercheur";
  }

  function networkFeed() {
    var items = [];
    try {
      var members = global.SycamV222 && global.SycamV222.getMembers ? global.SycamV222.getMembers() : [];
      var msgs = {};
      try {
        msgs = JSON.parse(localStorage.getItem("sycam_network_msgs_v222") || "{}");
      } catch (e) {}
      members.slice(0, 6).forEach(function (m) {
        var arr = msgs[m.id] || [];
        var last = arr[arr.length - 1];
        items.push({
          who: m.name,
          tx: last ? last.text : "Nouveau sur le réseau SYCAM · " + (m.title || ""),
          tm: last ? (last.at || "").replace("T", " ").slice(0, 16) : "réseau"
        });
      });
    } catch (e) {}
    if (!items.length) {
      items = [
        { who: "SYCAM-PUB", tx: "Bienvenue sur le fil réseau. Ajoutez des contacts dans Réseau.", tm: "système" },
        { who: "JARVIS", tx: "Explorez HAL depuis Actualités ou Explorer pour enrichir votre veille.", tm: "astuce" }
      ];
    }
    return items.slice(0, 5);
  }

  function renderChallenges(host, filter) {
    filter = filter || "open";
    var list = getChallenges().filter(function (c) {
      if (filter === "all") return true;
      if (filter === "open") return c.status === "open";
      if (filter === "upcoming") return c.status === "upcoming";
      if (filter === "done") return c.status === "done";
      return true;
    });
    if (!list.length) {
      host.innerHTML = '<div style="font-size:12px;color:#94a3b8;padding:8px 0">Aucun challenge dans cet onglet.</div>';
      return;
    }
    host.innerHTML = list
      .map(function (c) {
        return (
          '<article class="v234-ch"><div class="badges">' +
          '<span class="bdg ' +
          (c.status === "open" ? "open" : "") +
          '">' +
          esc(c.badge) +
          "</span>" +
          '<span class="bdg">' +
          esc(c.mode) +
          "</span></div>" +
          "<h4>" +
          esc(c.title) +
          '</h4><p class="ex">' +
          esc(c.excerpt) +
          '</p><div class="tags">' +
          (c.tags || [])
            .map(function (t) {
              return '<span class="tag">' + esc(t) + "</span>";
            })
            .join("") +
          '</div><div class="meta">Publié par ' +
          esc(c.org) +
          (c.days ? " · " + c.days + " j restants" : "") +
          '</div><div class="acts">' +
          '<button type="button" class="p" data-ch-go="publish">Participer</button>' +
          '<button type="button" class="g" data-ch-go="explorer">Voir ressources</button>' +
          "</div></article>"
        );
      })
      .join("");
    host.querySelectorAll("[data-ch-go]").forEach(function (b) {
      b.onclick = function () {
        var g = b.getAttribute("data-ch-go");
        if (g === "publish" && global.SycamV221) global.SycamV221.openPublish("article");
        if (g === "explorer" && global.SycamV220) global.SycamV220.openExplorer("Cameroun");
      };
    });
  }

  async function renderNewsMini(host) {
    host.innerHTML = '<div style="font-size:12px;color:#94a3b8">Chargement actualités…</div>';
    var items = [];
    try {
      if (global.SycamV220 && global.SycamV220.buildFeed) {
        items = await global.SycamV220.buildFeed({ withHal: true, q: "Cameroun science" });
        items = (items || []).filter(function (i) {
          return i.kind === "news" || i.tag === "HAL" || i.tag === "News";
        });
      }
    } catch (e) {}
    if (!items.length) {
      host.innerHTML =
        '<div style="font-size:12px;color:#94a3b8">Pas d’actualité chargée. <button type="button" id="v234OpenNews" style="color:#2dd4bf;background:0;border:0;font-weight:700">Ouvrir Actualités</button></div>';
      var bn = $("v234OpenNews");
      if (bn)
        bn.onclick = function () {
          if (global.SycamV230) global.SycamV230.openNews();
        };
      return;
    }
    host.innerHTML =
      items
        .slice(0, 3)
        .map(function (i) {
          return (
            '<article class="v234-news-mini"><span style="font-size:10px;font-weight:800;background:#2563eb;color:#fff;padding:2px 6px;border-radius:4px">' +
            esc(i.tag) +
            "</span><h4>" +
            esc(i.title) +
            '</h4><div class="m">' +
            esc(i.meta) +
            "</div></article>"
          );
        })
        .join("") +
      '<button type="button" id="v234AllNews" style="border:0;background:#1f2937;color:#e2e8f0;border-radius:10px;padding:10px 12px;font-weight:700;width:100%;margin-top:4px">Toutes les actualités →</button>';
    $("v234AllNews").onclick = function () {
      if (global.SycamV230) global.SycamV230.openNews();
    };
  }

  function injectEnrichment() {
    var home = $("pg-mobilehome");
    if (!home || home.style.display === "none") return;
    ensureStyles();

    var box = $("v234HomeExtra");
    if (!box) {
      box = document.createElement("div");
      box.id = "v234HomeExtra";
      var shortcuts = $("v230Shortcuts");
      if (shortcuts && shortcuts.parentNode) {
        shortcuts.parentNode.insertBefore(box, shortcuts);
      } else {
        home.insertBefore(box, home.firstChild);
      }
    }

    var ch = getChallenges();
    var openN = ch.filter(function (c) {
      return c.status === "open";
    }).length;
    var upN = ch.filter(function (c) {
      return c.status === "upcoming";
    }).length;
    var doneN = ch.filter(function (c) {
      return c.status === "done";
    }).length;

    box.innerHTML =
      '<div class="v234-greet"><h2>Salut ' +
      esc(profileName()) +
      ' 👋</h2><p>Propulsez vos recherches — publiez, collaborez, gagnez en visibilité.</p></div>' +
      '<div class="v234-kpis">' +
      '<div class="v234-kpi"><div class="n">' +
      openN +
      '</div><div class="l">Challenges en cours</div></div>' +
      '<div class="v234-kpi"><div class="n">' +
      upN +
      '</div><div class="l">À venir</div></div>' +
      '<div class="v234-kpi"><div class="n">' +
      doneN +
      '</div><div class="l">Terminés</div></div>' +
      '<div class="v234-kpi"><div class="n">' +
      (openN + upN + doneN) +
      '</div><div class="l">Total challenges</div></div></div>' +
      '<div class="v234-sec">Challenges innovation <button type="button" id="v234ChAll">Voir tout</button></div>' +
      '<div class="v234-tabs" id="v234ChTabs">' +
      '<button type="button" class="on" data-cf="open">En cours</button>' +
      '<button type="button" data-cf="upcoming">À venir</button>' +
      '<button type="button" data-cf="done">Terminés</button>' +
      "</div>" +
      '<div class="v234-chips">' +
      '<button type="button" class="on" data-city="all">Partout</button>' +
      '<button type="button" data-city="douala">Douala</button>' +
      '<button type="button" data-city="yaounde">Yaoundé</button>' +
      '<button type="button" data-city="online">En ligne</button>' +
      "</div>" +
      '<div id="v234ChList"></div>' +
      '<div class="v234-sec">Fil réseau <button type="button" id="v234Net">Ouvrir Réseau</button></div>' +
      '<div id="v234Fil"></div>' +
      '<div class="v234-sec">Actualités <button type="button" id="v234News">Tout voir</button></div>' +
      '<div id="v234NewsMini"></div>' +
      '<div class="v234-sec">Partenaires & talents</div>' +
      '<div class="v234-partners" id="v234Partners"></div>';

    renderChallenges($("v234ChList"), "open");
    $("v234Fil").innerHTML = networkFeed()
      .map(function (f) {
        return (
          '<div class="v234-feed-item"><div class="who">' +
          esc(f.who) +
          '</div><div class="tx">' +
          esc(f.tx) +
          '</div><div class="tm">' +
          esc(f.tm) +
          "</div></div>"
        );
      })
      .join("");

    var partners = [];
    try {
      partners =
        global.SycamV222 && global.SycamV222.getMembers
          ? global.SycamV222.getMembers().slice(0, 6)
          : [];
    } catch (e) {}
    $("v234Partners").innerHTML = (partners.length ? partners : [{ name: "Dr SYCAM", title: "Innovation", avatar: "S" }])
      .map(function (m) {
        return (
          '<div class="v234-partner"><div class="av">' +
          esc(m.avatar || (m.name || "?").charAt(0)) +
          '</div><div class="nm">' +
          esc(m.name) +
          '</div><div class="rl">' +
          esc(m.title || m.dept || "") +
          "</div></div>"
        );
      })
      .join("");

    renderNewsMini($("v234NewsMini"));

    $("v234ChTabs").querySelectorAll("[data-cf]").forEach(function (b) {
      b.onclick = function () {
        $("v234ChTabs").querySelectorAll("button").forEach(function (x) {
          x.classList.remove("on");
        });
        b.classList.add("on");
        renderChallenges($("v234ChList"), b.getAttribute("data-cf"));
      };
    });
    box.querySelectorAll("[data-city]").forEach(function (b) {
      b.onclick = function () {
        box.querySelectorAll("[data-city]").forEach(function (x) {
          x.classList.remove("on");
        });
        b.classList.add("on");
      };
    });
    $("v234Net").onclick = function () {
      if (global.SycamV222) global.SycamV222.openNetwork({});
    };
    $("v234News").onclick = function () {
      if (global.SycamV230) global.SycamV230.openNews();
    };
    $("v234ChAll").onclick = function () {
      renderChallenges($("v234ChList"), "all");
    };
  }

  function patch() {
    if (!global.SycamV219 || !global.SycamV219.openMobileHome) return;
    if (global.SycamV219.__v234) return;
    var orig = global.SycamV219.openMobileHome.bind(global.SycamV219);
    global.SycamV219.openMobileHome = function () {
      orig();
      setTimeout(injectEnrichment, 120);
      setTimeout(injectEnrichment, 400);
    };
    global.SycamV219.__v234 = true;
  }

  function boot() {
    patch();
    setTimeout(patch, 500);
    setTimeout(injectEnrichment, 800);
    console.log("[V234] Home feed + challenges", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV234 = {
    version: VERSION,
    injectEnrichment: injectEnrichment,
    getChallenges: getChallenges
  };
})(typeof window !== "undefined" ? window : this);
