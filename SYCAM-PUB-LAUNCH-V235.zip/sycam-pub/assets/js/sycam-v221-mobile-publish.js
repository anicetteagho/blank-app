/*! SYCAM V221 — sycam-v221-mobile-publish.js
 * Écran Publier mobile : Article | Dataset | PDF | Vidéo
 * Soumission NEXUS publication.create + Resource Bus
 */
(function (global) {
  "use strict";

  var VERSION = "221.0.0-mobile-publish";
  var DRAFT_KEY = "sycam_publish_draft_v221";
  var PUB_LOG = "sycam_publish_log_v221";

  var TYPES = [
    { id: "article", label: "Article", ico: "📄", hint: "Titre, résumé, mots-clés" },
    { id: "dataset", label: "Dataset", ico: "📊", hint: "Données, format, licence" },
    { id: "pdf", label: "PDF", ico: "📎", hint: "Document / cours / rapport" },
    { id: "video", label: "Vidéo", ico: "🎬", hint: "Démo scientifique, lien ou fichier" }
  ];

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }
  function load(key, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(key) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
  }

  function ensureStyles() {
    if ($("sycam-v221-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v221-css";
    s.textContent = [
      "#pg-publish-v221{padding:12px 14px 100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}",
      "#pg-publish-v221.on{display:block}",
      "#pg-publish-v221 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v221-sub{font-size:12px;color:#94a3b8;margin:0 0 12px}",
      ".v221-types{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}",
      ".v221-type{border:1px solid #1f2937;background:#111827;border-radius:12px;padding:12px;text-align:left;color:#e2e8f0;cursor:pointer;min-height:72px}",
      ".v221-type.on{border-color:#0d7377;background:#0f2a2c}",
      ".v221-type .ico{font-size:20px;display:block;margin-bottom:4px}",
      ".v221-type .lb{font-size:13px;font-weight:800}",
      ".v221-type .hn{font-size:10px;color:#94a3b8;margin-top:2px}",
      ".v221-card{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;margin-bottom:12px}",
      ".v221-card h3{margin:0 0 10px;font-size:13px;color:#2dd4bf}",
      ".v221-field{margin-bottom:10px}",
      ".v221-field label{display:block;font-size:11px;font-weight:700;color:#94a3b8;margin-bottom:4px}",
      ".v221-field input,.v221-field textarea,.v221-field select{width:100%;box-sizing:border-box;padding:11px 12px;border-radius:10px;border:1px solid #1f2937;background:#030712;color:#e2e8f0;font-size:14px;min-height:44px}",
      ".v221-field textarea{min-height:96px;resize:vertical}",
      ".v221-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}",
      ".v221-actions button{border:0;border-radius:10px;padding:12px 14px;font-weight:700;font-size:13px;cursor:pointer;background:#1f2937;color:#e2e8f0;min-height:44px}",
      ".v221-actions button.primary{background:#0d7377;color:#fff}",
      ".v221-actions button.ghost{background:transparent;border:1px solid #1f2937}",
      ".v221-hint{font-size:11px;color:#94a3b8;margin-top:6px}"
    ].join("");
    document.head.appendChild(s);
  }

  function showPage(id) {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  function fieldsFor(type) {
    var common =
      field("title", "Titre *", "text", "Titre scientifique") +
      field("abstract", "Résumé / description", "textarea", "Résumé court…");
    if (type === "article") {
      return (
        common +
        field("authors", "Auteurs", "text", "Nom1, Nom2") +
        field("keywords", "Mots-clés", "text", "énergie, Cameroun…") +
        field("department", "Département / labo", "text", "ex. Génie")
      );
    }
    if (type === "dataset") {
      return (
        common +
        field("format", "Format", "text", "CSV, XLSX, JSON…") +
        field("license", "Licence", "text", "CC-BY-4.0") +
        field("keywords", "Mots-clés", "text", "données, terrain…")
      );
    }
    if (type === "pdf") {
      return (
        common +
        field("authors", "Auteur", "text", "Votre nom") +
        '<div class="v221-field"><label>Fichier PDF</label><input type="file" id="pubFile" accept=".pdf,application/pdf"/></div>'
      );
    }
    if (type === "video") {
      return (
        common +
        field("videoUrl", "Lien vidéo (optionnel)", "url", "https://…") +
        '<div class="v221-field"><label>Fichier vidéo (optionnel)</label><input type="file" id="pubFile" accept="video/*"/></div>' +
        field("keywords", "Tags", "text", "démo, protocole…")
      );
    }
    return common;
  }

  function field(id, label, type, placeholder) {
    if (type === "textarea") {
      return (
        '<div class="v221-field"><label for="pub_' +
        id +
        '">' +
        esc(label) +
        '</label><textarea id="pub_' +
        id +
        '" placeholder="' +
        esc(placeholder) +
        '"></textarea></div>'
      );
    }
    return (
      '<div class="v221-field"><label for="pub_' +
      id +
      '">' +
      esc(label) +
      '</label><input id="pub_' +
      id +
      '" type="' +
      type +
      '" placeholder="' +
      esc(placeholder) +
      '"/></div>'
    );
  }

  function val(id) {
    var el = $("pub_" + id);
    return el ? String(el.value || "").trim() : "";
  }

  function readFileAsMeta(file) {
    return new Promise(function (resolve) {
      if (!file) return resolve(null);
      // store metadata only (no large binary in localStorage)
      resolve({
        name: file.name,
        size: file.size,
        mime: file.type,
        lastModified: file.lastModified
      });
    });
  }

  async function submitPublish(type) {
    var title = val("title");
    if (!title) {
      toast("Titre obligatoire");
      return;
    }
    var fileInput = $("pubFile");
    var fileMeta = await readFileAsMeta(fileInput && fileInput.files && fileInput.files[0]);

    var payload = {
      title: title,
      abstract: val("abstract"),
      type: type,
      authors: val("authors"),
      keywords: val("keywords"),
      department: val("department"),
      format: val("format"),
      license: val("license"),
      videoUrl: val("videoUrl"),
      file: fileMeta,
      createdAt: new Date().toISOString()
    };

    // draft save
    save(DRAFT_KEY, payload);

    var result;
    if (global.SycamV210 && global.SycamV210.execute) {
      result = await global.SycamV210.execute("publication.create", payload, {});
    } else if (global.SycamV210 && global.SycamV210.putResource) {
      result = {
        ok: true,
        data: global.SycamV210.putResource({
          type: "publication",
          title: title,
          source: "sycam",
          meta: payload,
          capabilities: ["read", "preview"]
        })
      };
    } else {
      var bag = load("sycam_posts_local_v221", []);
      bag.unshift(Object.assign({ id: "p_" + Date.now() }, payload));
      save("sycam_posts_local_v221", bag.slice(0, 100));
      result = { ok: true, local: true };
    }

    var log = load(PUB_LOG, []);
    log.unshift({
      at: new Date().toISOString(),
      title: title,
      type: type,
      ok: !!(result && result.ok !== false && result.status !== "MANDATE_REQUIRED" && result.status !== "LEGAL_GATE" && result.status !== "USER_REFUSED" && result.status !== "REFUSED")
    });
    save(PUB_LOG, log.slice(0, 40));

    if (result && (result.status === "MANDATE_REQUIRED" || result.status === "LEGAL_GATE")) {
      toast("Validation conformité requise");
      if (global.SycamV212 && global.SycamV212.openLegal) global.SycamV212.openLegal();
      return;
    }
    if (result && result.ok === false) {
      toast(result.status || result.error || "Publication refusée");
      return;
    }

    toast("Publié · " + type);
    save(DRAFT_KEY, null);
    if (global.SycamV220 && global.SycamV220.refreshHomeFeed) {
      global.SycamV220.refreshHomeFeed("pub");
    }
    if (global.SycamV219 && global.SycamV219.openMobileHome) {
      setTimeout(function () {
        global.SycamV219.openMobileHome();
      }, 400);
    }
  }

  function openPublish(startType) {
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    var type = startType || "article";
    var draft = load(DRAFT_KEY, null);
    var page = showPage("pg-publish-v221");

    function paint() {
      page.innerHTML =
        "<h1>Publier</h1>" +
        '<p class="v221-sub">Une publication · champs selon le type · validation si gates actifs</p>' +
        '<div class="v221-types">' +
        TYPES.map(function (t) {
          return (
            '<button type="button" class="v221-type' +
            (t.id === type ? " on" : "") +
            '" data-type="' +
            t.id +
            '"><span class="ico">' +
            t.ico +
            '</span><span class="lb">' +
            t.label +
            '</span><div class="hn">' +
            esc(t.hint) +
            "</div></button>"
          );
        }).join("") +
        "</div>" +
        '<div class="v221-card"><h3>Détails — ' +
        esc(type) +
        "</h3>" +
        fieldsFor(type) +
        '<p class="v221-hint">Les fichiers volumineux : métadonnées locales ; binaire via Bridge / serveur plus tard.</p></div>' +
        '<div class="v221-actions">' +
        '<button type="button" class="primary" id="v221Submit">Publier</button>' +
        '<button type="button" class="ghost" id="v221Draft">Brouillon</button>' +
        '<button type="button" class="ghost" id="v221Cancel">Annuler</button>' +
        "</div>";

      page.querySelectorAll("[data-type]").forEach(function (b) {
        b.onclick = function () {
          type = b.getAttribute("data-type");
          paint();
        };
      });

      if (draft && draft.title) {
        ["title", "abstract", "authors", "keywords", "department", "format", "license", "videoUrl"].forEach(
          function (k) {
            var el = $("pub_" + k);
            if (el && draft[k]) el.value = draft[k];
          }
        );
      }

      $("v221Submit").onclick = function () {
        submitPublish(type);
      };
      $("v221Draft").onclick = function () {
        save(DRAFT_KEY, {
          title: val("title"),
          abstract: val("abstract"),
          type: type,
          authors: val("authors"),
          keywords: val("keywords")
        });
        toast("Brouillon enregistré");
      };
      $("v221Cancel").onclick = function () {
        if (global.SycamV219 && global.SycamV219.openMobileHome) global.SycamV219.openMobileHome();
        else history.back();
      };
    }

    paint();
  }

  function patchPublishNav() {
    document.addEventListener(
      "click",
      function (e) {
        var b =
          e.target &&
          e.target.closest &&
          e.target.closest(".sycam-v219-bottom-nav [data-nav='publish']");
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        openPublish("article");
      },
      true
    );
  }

  function boot() {
    patchPublishNav();
    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v221"] = {
        id: "sycam-v221",
        version: VERSION,
        global: "SycamV221",
        requires: ["sycam-v220"],
        provides: ["publish.mobile", "publish.composer"],
        modifies: [],
        routes: ["publish", "publier"],
        storage: [DRAFT_KEY, PUB_LOG],
        events: [],
        permissions: ["publish.create"],
        adr: ["ADR-023"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV221 = ["SycamV220"];
    }
    if (global.SycamV192 && global.SycamV192.ALIAS) {
      global.SycamV192.ALIAS.publish = "publish";
      global.SycamV192.ALIAS.publier = "publish";
    }
    if (typeof global.go === "function" && !global.__sycamV221Go) {
      global.__sycamV221Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "publish" || n === "publier") {
          openPublish("article");
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V221] Mobile publish", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV221 = {
    version: VERSION,
    openPublish: openPublish,
    TYPES: TYPES
  };
})(typeof window !== "undefined" ? window : this);
