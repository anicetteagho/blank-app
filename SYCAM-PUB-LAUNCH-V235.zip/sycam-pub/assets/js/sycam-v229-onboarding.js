/*! SYCAM V229 — sycam-v229-onboarding.js
 * Onboarding 3 écrans : Bienvenue · Mandat · PWA / Démarrer
 */
(function (global) {
  "use strict";

  var VERSION = "229.0.0-onboarding";
  var DONE_KEY = "sycam_onboard_done_v229";
  var STEP_KEY = "sycam_onboard_step_v229";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
      } catch (e) {}
    }
  }
  function isDone() {
    try {
      return localStorage.getItem(DONE_KEY) === "1";
    } catch (e) {
      return false;
    }
  }
  function setDone() {
    try {
      localStorage.setItem(DONE_KEY, "1");
    } catch (e) {}
  }
  function getStep() {
    try {
      return parseInt(localStorage.getItem(STEP_KEY) || "0", 10) || 0;
    } catch (e) {
      return 0;
    }
  }
  function setStep(i) {
    try {
      localStorage.setItem(STEP_KEY, String(i));
    } catch (e) {}
  }

  function ensureStyles() {
    if ($("sycam-v229-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v229-css";
    s.textContent = [
      "#pg-onboard-v229{position:fixed;inset:0;z-index:120;background:#0b1220;color:#e2e8f0;display:none;flex-direction:column;padding:calc(24px + env(safe-area-inset-top,0px)) 20px calc(24px + env(safe-area-inset-bottom,0px));box-sizing:border-box}",
      "#pg-onboard-v229.on{display:flex}",
      "#pg-onboard-v229 .brand{font-size:13px;font-weight:800;letter-spacing:.06em;color:#2dd4bf;text-transform:uppercase}",
      "#pg-onboard-v229 h1{margin:12px 0 8px;font-size:26px;color:#fff;line-height:1.2}",
      "#pg-onboard-v229 .lead{font-size:15px;line-height:1.5;color:#94a3b8;flex:1}",
      "#pg-onboard-v229 .dots{display:flex;gap:8px;margin:16px 0}",
      "#pg-onboard-v229 .dots i{width:8px;height:8px;border-radius:50%;background:#1f2937}",
      "#pg-onboard-v229 .dots i.on{background:#0d7377;width:22px;border-radius:6px}",
      "#pg-onboard-v229 .actions{display:flex;flex-direction:column;gap:10px}",
      "#pg-onboard-v229 button{border:0;border-radius:12px;padding:14px 16px;font-weight:800;font-size:15px;cursor:pointer;min-height:48px}",
      "#pg-onboard-v229 button.primary{background:#0d7377;color:#fff}",
      "#pg-onboard-v229 button.ghost{background:#1f2937;color:#e2e8f0}",
      "#pg-onboard-v229 button.link{background:transparent;color:#94a3b8;font-weight:600;font-size:13px}",
      "#pg-onboard-v229 .check{background:#111827;border:1px solid #1f2937;border-radius:12px;padding:12px;margin:12px 0;font-size:13px}",
      "#pg-onboard-v229 .check label{display:flex;gap:10px;align-items:flex-start;cursor:pointer}"
    ].join("");
    document.head.appendChild(s);
  }

  function openOnboarding(force, startStep) {
    ensureStyles();
    var step = typeof startStep === "number" ? startStep : getStep();
    if (step > 2) step = 0;
    setStep(step);

    var page = $("pg-onboard-v229");
    if (!page) {
      page = document.createElement("div");
      page.id = "pg-onboard-v229";
      document.body.appendChild(page);
    }
    page.classList.add("on");
    render(step);
  }

  function closeOnboarding() {
    var page = $("pg-onboard-v229");
    if (page) page.classList.remove("on");
  }

  function render(step) {
    setStep(step);
    var page = $("pg-onboard-v229");
    if (!page) return;

    var dots =
      "<div class='dots'>" +
      [0, 1, 2]
        .map(function (i) {
          return "<i class='" + (i === step ? "on" : "") + "'></i>";
        })
        .join("") +
      "</div>";

    if (step === 0) {
      page.innerHTML =
        '<div class="brand">SYCAM-PUB</div>' +
        "<h1>Bienvenue</h1>" +
        dots +
        '<div class="lead">Plateforme scientifique pour <b style="color:#e2e8f0">publier</b>, <b style="color:#e2e8f0">explorer</b>, collaborer et innover — pensée pour le terrain, le mobile et les universités africaines.<br/><br/>Unifier · Publier · Innover.</div>' +
        '<div class="actions">' +
        '<button type="button" class="primary" id="obNext">Continuer</button>' +
        '<button type="button" class="link" id="obSkip">Passer l’intro</button>' +
        "</div>";
      $("obNext").onclick = function () {
        render(1);
      };
      $("obSkip").onclick = finish;
      return;
    }

    if (step === 1) {
      var mandateOk =
        global.SycamV212 &&
        global.SycamV212.getMandate &&
        global.SycamV212.getMandate() &&
        global.SycamV212.getMandate().accepted;
      page.innerHTML =
        '<div class="brand">Étape 2 / 3</div>' +
        "<h1>Cadre & confiance</h1>" +
        dots +
        '<div class="lead">Les actions sensibles (publication, import, partage) passent par un <b style="color:#e2e8f0">mandat local</b> et votre consentement. Vos données restent d’abord sur cet appareil.</div>' +
        '<div class="check"><label><input type="checkbox" id="obAccept"/> J’ai compris le principe de validation locale et je souhaite continuer.</label></div>' +
        (mandateOk
          ? '<div style="font-size:12px;color:#34d399;margin-bottom:8px">✓ Mandat déjà accepté</div>'
          : "") +
        '<div class="actions">' +
        '<button type="button" class="primary" id="obLegal">Ouvrir conformité</button>' +
        '<button type="button" class="ghost" id="obNext">Continuer</button>' +
        '<button type="button" class="link" id="obBack">Retour</button>' +
        "</div>";
      $("obLegal").onclick = function () {
        if (global.SycamV212 && global.SycamV212.openLegal) {
          closeOnboarding();
          global.SycamV212.openLegal();
          // resume tip
          if (global.SycamV224 && global.SycamV224.pushNotif) {
            global.SycamV224.pushNotif({
              title: "Onboarding",
              body: "Revenez via Plus → ou SycamV229.openOnboarding(true, 1)",
              action: "home"
            });
          }
        } else {
          toast("Module conformité non chargé — vous pouvez continuer");
        }
      };
      $("obNext").onclick = function () {
        var cb = $("obAccept");
        if (cb && !cb.checked && !mandateOk) {
          toast("Cochez la case pour continuer");
          return;
        }
        render(2);
      };
      $("obBack").onclick = function () {
        render(0);
      };
      return;
    }

    // step 2
    var standalone =
      global.SycamV227 && global.SycamV227.isStandalone && global.SycamV227.isStandalone();
    page.innerHTML =
      '<div class="brand">Étape 3 / 3</div>' +
      "<h1>Prêt à démarrer</h1>" +
      dots +
      '<div class="lead">Installez SYCAM-PUB sur l’écran d’accueil pour un usage comme une app. Ensuite lancez la <b style="color:#e2e8f0">démo 5 min</b> ou allez directement à l’accueil.</div>' +
      (standalone
        ? '<div style="font-size:12px;color:#34d399;margin:8px 0">✓ Déjà en mode application</div>'
        : '<div style="font-size:12px;color:#94a3b8;margin:8px 0">Astuce : Chrome → Ajouter à l’écran d’accueil (serveur http/https requis)</div>') +
      '<div class="actions">' +
      '<button type="button" class="primary" id="obStart">Entrer dans SYCAM-PUB</button>' +
      '<button type="button" class="ghost" id="obPwa">État PWA</button>' +
      '<button type="button" class="ghost" id="obDemo">Lancer la démo 5 min</button>' +
      '<button type="button" class="link" id="obBack">Retour</button>' +
      "</div>";
    $("obStart").onclick = finish;
    $("obPwa").onclick = function () {
      if (global.SycamV227 && global.SycamV227.openPwaStatus) {
        closeOnboarding();
        global.SycamV227.openPwaStatus();
      } else toast("PWA non chargé");
    };
    $("obDemo").onclick = function () {
      setDone();
      closeOnboarding();
      if (global.SycamV225 && global.SycamV225.openDemo) global.SycamV225.openDemo();
      else finish();
    };
    $("obBack").onclick = function () {
      render(1);
    };
  }

  function finish() {
    setDone();
    setStep(0);
    closeOnboarding();
    toast("Bienvenue sur SYCAM-PUB");
    if (global.SycamV224 && global.SycamV224.pushNotif) {
      global.SycamV224.pushNotif({
        title: "Onboarding terminé",
        body: "Explorez Accueil, Publier, Réseau ou la Démo 5 min.",
        action: "home"
      });
    }
    if (global.SycamV219 && global.SycamV219.openMobileHome) {
      global.SycamV219.openMobileHome();
    }
  }

  function resetOnboarding() {
    try {
      localStorage.removeItem(DONE_KEY);
      localStorage.setItem(STEP_KEY, "0");
    } catch (e) {}
    openOnboarding(true, 0);
  }

  function patchPlusWithOnboard() {
    // soft: ensure plus hub still works; add entry via goModule if V228 present
    if (global.SycamV228 && !global.SycamV228.__ob229) {
      var orig = global.SycamV228.openPlusHub;
      if (typeof orig === "function") {
        global.SycamV228.openPlusHub = function () {
          orig.apply(global.SycamV228, arguments);
          setTimeout(function () {
            var page = $("pg-plusmenu");
            if (!page || page.querySelector("#v229OnboardBtn")) return;
            var card = document.createElement("div");
            card.className = "v219-card";
            card.innerHTML =
              "<h3>Aide</h3><div class=\"v219-grid-2\">" +
              '<button type="button" class="v219-tile" id="v229OnboardBtn"><span class="t-ico">🚪</span><span class="t-label">Onboarding</span><span class="t-hint">Revoir l’intro</span></button>' +
              "</div>";
            page.appendChild(card);
            $("v229OnboardBtn").onclick = function () {
              resetOnboarding();
            };
          }, 50);
        };
        global.SycamV228.__ob229 = true;
      }
    }
  }

  function boot() {
    patchPlusWithOnboard();
    setTimeout(patchPlusWithOnboard, 500);

    // Auto-open géré par index.html après openMobileHome (évite écran noir)
    // if (!isDone()) { setTimeout(function () { openOnboarding(false, getStep()); }, 450); }

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v229"] = {
        id: "sycam-v229",
        version: VERSION,
        global: "SycamV229",
        requires: ["sycam-v228"],
        provides: ["onboarding"],
        modifies: [],
        routes: ["onboarding", "welcome"],
        storage: [DONE_KEY, STEP_KEY],
        events: [],
        permissions: ["ui.onboarding"],
        adr: ["ADR-031"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV229 = ["SycamV228"];
    }
    if (typeof global.go === "function" && !global.__sycamV229Go) {
      global.__sycamV229Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "onboarding" || n === "welcome") {
          openOnboarding(true, 0);
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V229] Onboarding", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV229 = {
    version: VERSION,
    openOnboarding: openOnboarding,
    resetOnboarding: resetOnboarding,
    isDone: isDone
  };
})(typeof window !== "undefined" ? window : this);
