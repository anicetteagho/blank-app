/*! SYCAM V226 — sycam-v226-offline-mode.js
 * Mode hors-ligne :
 *  - Indicateur header
 *  - File d'actions pending
 *  - Flush auto au retour réseau
 *  - Écran de gestion
 */
(function (global) {
  "use strict";

  var VERSION = "226.0.0-offline-mode";
  var QUEUE_KEY = "sycam_offline_queue_v226";
  var LOG_KEY = "sycam_offline_log_v226";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }
  function load(key, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(key) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
  }

  function isOnline() {
    return typeof navigator !== "undefined" ? !!navigator.onLine : true;
  }

  function getQueue() {
    return load(QUEUE_KEY, []);
  }

  function setQueue(q) {
    save(QUEUE_KEY, q.slice(0, 100));
  }

  function log(entry) {
    var a = load(LOG_KEY, []);
    a.unshift(Object.assign({ at: new Date().toISOString() }, entry));
    save(LOG_KEY, a.slice(0, 40));
  }

  function enqueue(action) {
    var q = getQueue();
    var item = {
      id: "off_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
      type: action.type || "generic",
      label: action.label || action.type || "Action",
      payload: action.payload || {},
      createdAt: new Date().toISOString(),
      status: "pending"
    };
    q.push(item);
    setQueue(q);
    log({ evt: "enqueue", id: item.id, type: item.type });
    updatePill();
    if (global.SycamV224 && global.SycamV224.pushNotif) {
      global.SycamV224.pushNotif({
        title: "Hors-ligne · en file",
        body: item.label,
        action: "home"
      });
    }
    return item;
  }

  async function executeItem(item) {
    try {
      if (item.type === "publication.create" && global.SycamV210 && global.SycamV210.execute) {
        var r = await global.SycamV210.execute("publication.create", item.payload || {}, {});
        return !!(r && r.ok !== false && !r.status);
      }
      if (item.type === "hal.search" && global.SycamV220 && global.SycamV220.fromHal) {
        await global.SycamV220.fromHal((item.payload && item.payload.q) || "science");
        return true;
      }
      if (item.type === "resource.put" && global.SycamV210 && global.SycamV210.putResource) {
        global.SycamV210.putResource(item.payload || { title: item.label, type: "note" });
        return true;
      }
      if (item.type === "notif" && global.SycamV224 && global.SycamV224.pushNotif) {
        global.SycamV224.pushNotif(item.payload || { title: item.label });
        return true;
      }
      // generic: mirror to file queue
      if (global.SycamV218 && global.SycamV218.enqueueOutbox) {
        global.SycamV218.enqueueOutbox({
          type: "note",
          title: "Replay · " + item.label,
          body: JSON.stringify(item.payload || {}).slice(0, 500),
          source: "offline-flush",
          requiresApproval: false
        });
      }
      return true;
    } catch (e) {
      log({ evt: "exec_error", id: item.id, error: String(e.message || e) });
      return false;
    }
  }

  async function flush() {
    if (!isOnline()) {
      toast("Toujours hors-ligne");
      return { flushed: 0, left: getQueue().length };
    }
    var q = getQueue();
    var kept = [];
    var flushed = 0;
    for (var i = 0; i < q.length; i++) {
      var ok = await executeItem(q[i]);
      if (ok) {
        flushed++;
        log({ evt: "flushed", id: q[i].id });
      } else {
        kept.push(q[i]);
      }
    }
    setQueue(kept);
    updatePill();
    toast("Rejoué : " + flushed + " · reste " + kept.length);
    if (flushed && global.SycamV224 && global.SycamV224.pushNotif) {
      global.SycamV224.pushNotif({
        title: "File hors-ligne synchronisée",
        body: flushed + " action(s) rejouée(s)",
        action: "home"
      });
    }
    return { flushed: flushed, left: kept.length };
  }

  function ensureStyles() {
    if ($("sycam-v226-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v226-css";
    s.textContent = [
      "#v219OnlinePill.off{background:#7f1d1d;color:#fecaca}",
      "#v219OnlinePill.pending{background:#78350f;color:#fde68a}",
      "#pg-offline-v226{padding:14px;padding-bottom:100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}",
      "#pg-offline-v226.on{display:block}",
      "#pg-offline-v226 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v226-sub{font-size:12px;color:#94a3b8;margin:0 0 12px}",
      ".v226-card{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;margin-bottom:12px}",
      ".v226-card h3{margin:0 0 8px;font-size:13px;color:#2dd4bf}",
      ".v226-row{font-size:12px;padding:8px 0;border-bottom:1px solid #1f2937}",
      ".v226-actions button{border:0;border-radius:10px;padding:11px 14px;font-weight:700;font-size:12px;cursor:pointer;background:#1f2937;color:#e2e8f0;margin:4px 4px 0 0;min-height:44px}",
      ".v226-actions button.primary{background:#0d7377;color:#fff}",
      ".v226-ok{color:#34d399}.v226-no{color:#f87171}"
    ].join("");
    document.head.appendChild(s);
  }

  function updatePill() {
    var pill = $("v219OnlinePill");
    if (!pill) return;
    var qn = getQueue().length;
    pill.classList.remove("off", "pending");
    if (!isOnline()) {
      pill.textContent = qn ? "Hors-ligne · " + qn : "Hors-ligne";
      pill.classList.add("off");
    } else if (qn) {
      pill.textContent = "En ligne · " + qn + " en file";
      pill.classList.add("pending");
    } else {
      // keep device/api/local if set by others — only override if empty-ish
      var t = pill.textContent || "";
      if (t.indexOf("Hors-ligne") !== -1 || t.indexOf("en file") !== -1 || t === "Local") {
        pill.textContent = "En ligne";
      }
    }
  }

  function showPage(id) {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  function openOffline() {
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    var page = showPage("pg-offline-v226");
    var q = getQueue();
    page.innerHTML =
      "<h1>Mode hors-ligne</h1>" +
      '<p class="v226-sub">Actions en attente · rejeu au retour réseau</p>' +
      '<div class="v226-card"><h3>État</h3>' +
      '<div class="v226-row">Réseau : <b class="' +
      (isOnline() ? "v226-ok" : "v226-no") +
      '">' +
      (isOnline() ? "en ligne" : "hors-ligne") +
      "</b></div>" +
      '<div class="v226-row">File : <b>' +
      q.length +
      "</b> action(s)</div></div>" +
      '<div class="v226-card"><h3>File d’attente</h3>' +
      (q.length
        ? q
            .map(function (item) {
              return (
                '<div class="v226-row"><b>' +
                esc(item.label) +
                "</b><br/><small>" +
                esc(item.type) +
                " · " +
                esc((item.createdAt || "").replace("T", " ").slice(0, 19)) +
                "</small></div>"
              );
            })
            .join("")
        : '<div class="v226-row">Vide</div>') +
      "</div>" +
      '<div class="v226-actions">' +
      '<button type="button" class="primary" id="v226Flush">Rejouer maintenant</button>' +
      '<button type="button" id="v226Add">+ Action test</button>' +
      '<button type="button" id="v226Clear">Vider la file</button>' +
      '<button type="button" id="v226Home">Accueil</button>' +
      "</div>";

    $("v226Flush").onclick = function () {
      flush().then(function () {
        openOffline();
      });
    };
    $("v226Add").onclick = function () {
      enqueue({
        type: "resource.put",
        label: "Note test hors-ligne",
        payload: {
          type: "note",
          title: "Note créée hors-ligne " + new Date().toLocaleTimeString(),
          source: "offline",
          capabilities: ["read"]
        }
      });
      toast("Ajouté à la file");
      openOffline();
    };
    $("v226Clear").onclick = function () {
      setQueue([]);
      updatePill();
      openOffline();
    };
    $("v226Home").onclick = function () {
      if (global.SycamV219) global.SycamV219.openMobileHome();
    };
  }

  /** Public helper: queue if offline else run */
  async function runOrQueue(type, label, payload, onlineFn) {
    if (!isOnline()) {
      return { queued: true, item: enqueue({ type: type, label: label, payload: payload }) };
    }
    if (typeof onlineFn === "function") {
      var r = await onlineFn();
      return { queued: false, result: r };
    }
    return { queued: false };
  }

  function boot() {
    ensureStyles();
    window.addEventListener("online", function () {
      updatePill();
      toast("Réseau de retour");
      flush();
    });
    window.addEventListener("offline", function () {
      updatePill();
      toast("Mode hors-ligne");
      if (global.SycamV224 && global.SycamV224.pushNotif) {
        global.SycamV224.pushNotif({
          title: "Hors-ligne",
          body: "Les actions réseau seront mises en file.",
          action: "home"
        });
      }
    });
    setTimeout(updatePill, 400);
    setInterval(updatePill, 10000);

    // click pill opens offline screen
    setTimeout(function () {
      var pill = $("v219OnlinePill");
      if (pill && !pill.__v226) {
        pill.__v226 = true;
        pill.style.cursor = "pointer";
        pill.title = "État réseau / file hors-ligne";
        pill.onclick = function () {
          openOffline();
        };
      }
    }, 600);

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v226"] = {
        id: "sycam-v226",
        version: VERSION,
        global: "SycamV226",
        requires: ["sycam-v225"],
        provides: ["offline.queue", "offline.flush"],
        modifies: [],
        routes: ["offline"],
        storage: [QUEUE_KEY, LOG_KEY],
        events: ["online", "offline"],
        permissions: ["offline.local"],
        adr: ["ADR-028"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV226 = ["SycamV225"];
    }
    if (typeof global.go === "function" && !global.__sycamV226Go) {
      global.__sycamV226Go = true;
      var orig = global.go;
      global.go = function (name) {
        if (String(name || "").toLowerCase() === "offline") {
          openOffline();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V226] Offline mode", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV226 = {
    version: VERSION,
    isOnline: isOnline,
    enqueue: enqueue,
    flush: flush,
    getQueue: getQueue,
    openOffline: openOffline,
    runOrQueue: runOrQueue,
    updatePill: updatePill
  };
})(typeof window !== "undefined" ? window : this);
