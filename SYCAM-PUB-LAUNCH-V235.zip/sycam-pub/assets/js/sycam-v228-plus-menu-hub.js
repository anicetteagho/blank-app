/*! SYCAM V228 — sycam-v228-plus-menu-hub.js
 * Menu Plus complet : tout accessible sans console
 */
(function (global) {
  "use strict";

  var VERSION = "228.0.0-plus-menu-hub";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
      } catch (e) {}
    }
  }

  function tile(id, ico, label, hint, available) {
    var dis = available === false;
    return (
      '<button type="button" class="v219-tile" data-go-m="' +
      esc(id) +
      '"' +
      (dis ? ' style="opacity:.45"' : "") +
      '><span class="t-ico">' +
      ico +
      '</span><span class="t-label">' +
      esc(label) +
      '</span><span class="t-hint">' +
      esc(hint) +
      (dis ? " · bientot" : "") +
      "</span></button>"
    );
  }

  function goModule(name) {
    name = String(name || "").toLowerCase();
    var map = {
      jarvis: function () {
        if (global.SycamV210 && global.SycamV210.openNexusSoftware) global.SycamV210.openNexusSoftware();
        else if (global.SycamV209 && global.SycamV209.openNexus) global.SycamV209.openNexus();
        else toast("JARVIS non chargé");
      },
      bridge: function () {
        if (global.SycamV211 && global.SycamV211.openBridge) global.SycamV211.openBridge();
        else toast("Data Bridge absent");
      },
      explorer: function () {
        if (global.SycamV220 && global.SycamV220.openExplorer) global.SycamV220.openExplorer("");
        else toast("Explorer absent");
      },
      publish: function () {
        if (global.SycamV221 && global.SycamV221.openPublish) global.SycamV221.openPublish("article");
      },
      reseau: function () {
        if (global.SycamV222 && global.SycamV222.openNetwork) global.SycamV222.openNetwork({});
      },
      stories: function () {
        if (global.SycamV223 && global.SycamV223.openCreate) global.SycamV223.openCreate();
      },
      notifs: function () {
        if (global.SycamV224 && global.SycamV224.openPanel) global.SycamV224.openPanel();
      },
      legal: function () {
        if (global.SycamV212 && global.SycamV212.openLegal) global.SycamV212.openLegal();
      },
      gates: function () {
        if (global.SycamV213 && global.SycamV213.openGates) global.SycamV213.openGates();
      },
      labready: function () {
        if (global.SycamV214 && global.SycamV214.openLabReady) global.SycamV214.openLabReady();
      },
      harden: function () {
        if (global.SycamV216 && global.SycamV216.openHarden) global.SycamV216.openHarden();
      },
      device: function () {
        if (global.SycamV217 && global.SycamV217.openDevice) global.SycamV217.openDevice();
      },
      queue: function () {
        if (global.SycamV218 && global.SycamV218.openQueue) global.SycamV218.openQueue();
      },
      gateway: function () {
        if (global.SycamV215 && global.SycamV215.openGateway) global.SycamV215.openGateway();
      },
      mission: function () {
        if (global.SycamV219 && global.SycamV219.openMissionControl) global.SycamV219.openMissionControl();
      },
      offline: function () {
        if (global.SycamV226 && global.SycamV226.openOffline) global.SycamV226.openOffline();
      },
      pwa: function () {
        if (global.SycamV227 && global.SycamV227.openPwaStatus) global.SycamV227.openPwaStatus();
      },
      demo: function () {
        if (global.SycamV225 && global.SycamV225.openDemo) global.SycamV225.openDemo();
      },
      home: function () {
        if (global.SycamV219 && global.SycamV219.openMobileHome) global.SycamV219.openMobileHome();
      }
    };
    if (map[name]) map[name]();
    else toast(name);
  }

  function openPlusHub() {
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    // mark nav
    try {
      document.querySelectorAll(".sycam-v219-bottom-nav button").forEach(function (b) {
        b.classList.toggle("on", b.getAttribute("data-nav") === "plus");
      });
    } catch (e) {}

    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $("pg-plusmenu");
    if (!page) {
      page = document.createElement("section");
      page.id = "pg-plusmenu";
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");

    var online = global.SycamV226 && global.SycamV226.isOnline ? global.SycamV226.isOnline() : navigator.onLine;
    var qn = global.SycamV226 && global.SycamV226.getQueue ? global.SycamV226.getQueue().length : 0;
    var standalone = global.SycamV227 && global.SycamV227.isStandalone && global.SycamV227.isStandalone();

    page.innerHTML =
      "<h1>Plus</h1>" +
      '<p class="v219-sub">Hub SYCAM · une destination claire par fonction</p>' +
      '<div class="v219-card"><h3>État rapide</h3>' +
      '<div class="v219-row"><span>Réseau</span><span>' +
      (online ? "en ligne" : "hors-ligne") +
      (qn ? " · " + qn + " en file" : "") +
      "</span></div>" +
      '<div class="v219-row"><span>PWA</span><span>' +
      (standalone ? "installée" : "navigateur") +
      "</span></div></div>" +
      '<div class="v219-card"><h3>Travail scientifique</h3><div class="v219-grid-2">' +
      tile("jarvis", "🤖", "JARVIS", "Orchestrateur", !!global.SycamV210 || !!global.SycamV209) +
      tile("explorer", "🔍", "Explorer", "HAL / recherche", !!global.SycamV220) +
      tile("publish", "✍️", "Publier", "Article · PDF · vidéo", !!global.SycamV221) +
      tile("bridge", "📥", "Data Bridge", "Import local", !!global.SycamV211) +
      "</div></div>" +
      '<div class="v219-card"><h3>Social & contenu</h3><div class="v219-grid-2">' +
      tile("reseau", "👥", "Réseau", "Messages · groupes", !!global.SycamV222) +
      tile("stories", "⭕", "Stories", "Statut 24 h", !!global.SycamV223) +
      tile("notifs", "🔔", "Notifications", "Centre d’alertes", !!global.SycamV224) +
      tile("home", "🏠", "Accueil", "Fil live", !!global.SycamV219) +
      "</div></div>" +
      '<div class="v219-card"><h3>Gouvernance</h3><div class="v219-grid-2">' +
      tile("legal", "⚖️", "Conformité", "Mandat · droits", !!global.SycamV212) +
      tile("gates", "🛡️", "Gates", "Écritures L2/L3", !!global.SycamV213) +
      tile("labready", "🏛️", "Labo prêt", "Score institution", !!global.SycamV214) +
      tile("harden", "🔒", "Durcissement", "Secrets / scan", !!global.SycamV216) +
      "</div></div>" +
      '<div class="v219-card"><h3>Appareil & système</h3><div class="v219-grid-2">' +
      tile("device", "📱", "Rattachement", "Termux local", !!global.SycamV217) +
      tile("queue", "📬", "File locale", "Termux ↔ UI", !!global.SycamV218) +
      tile("gateway", "🌐", "Passerelle API", "/api/jarvis", !!global.SycamV215) +
      tile("offline", "📡", "Hors-ligne", "File à rejouer", !!global.SycamV226) +
      tile("pwa", "📲", "PWA", "Installer l’app", !!global.SycamV227) +
      tile("mission", "🎛️", "Mission Control", "Vue unique", !!global.SycamV219) +
      tile("demo", "🎬", "Démo 5 min", "Parcours guidé", !!global.SycamV225) +
      "</div></div>";

    page.querySelectorAll("[data-go-m]").forEach(function (b) {
      b.onclick = function () {
        goModule(b.getAttribute("data-go-m"));
      };
    });
  }

  function patchPlus() {
    if (!global.SycamV219) return;
    global.SycamV219.openPlusMenu = openPlusHub;
    // also patch bottom nav plus
    document.addEventListener(
      "click",
      function (e) {
        var b =
          e.target &&
          e.target.closest &&
          e.target.closest(".sycam-v219-bottom-nav [data-nav='plus']");
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        openPlusHub();
      },
      true
    );
  }

  function boot() {
    patchPlus();
    setTimeout(patchPlus, 400);

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v228"] = {
        id: "sycam-v228",
        version: VERSION,
        global: "SycamV228",
        requires: ["sycam-v227"],
        provides: ["ui.plus.hub"],
        modifies: ["SycamV219.openPlusMenu"],
        routes: ["plus"],
        storage: [],
        events: [],
        permissions: ["ui.shell"],
        adr: ["ADR-030"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV228 = ["SycamV227"];
    }
    if (typeof global.go === "function" && !global.__sycamV228Go) {
      global.__sycamV228Go = true;
      var orig = global.go;
      global.go = function (name) {
        if (String(name || "").toLowerCase() === "plus") {
          openPlusHub();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V228] Plus menu hub", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV228 = {
    version: VERSION,
    openPlusHub: openPlusHub
  };
})(typeof window !== "undefined" ? window : this);
