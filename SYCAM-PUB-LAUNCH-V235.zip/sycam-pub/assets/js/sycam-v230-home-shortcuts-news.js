/*! SYCAM V230 — sycam-v230-home-shortcuts-news.js
 * Accueil : grille raccourcis institutionnels (tuiles carrées)
 * Actualités : interface dédiée (plus de flux news massif sur Accueil)
 */
(function (global) {
  "use strict";

  var VERSION = "230.0.0-home-shortcuts-news";

  var SHORTCUTS = [
    { id: "articles", label: "Articles", ico: "📄", go: "publish", arg: "article" },
    { id: "theses", label: "Thèses", ico: "🎓", go: "explorer", q: "thèse" },
    { id: "datasets", label: "Datasets", ico: "📊", go: "publish", arg: "dataset" },
    { id: "themes", label: "Thèmes", ico: "🏷️", go: "explorer", q: "thème" },
    { id: "projets", label: "Projets", ico: "💼", go: "mission" },
    { id: "donnees", label: "Données", ico: "🗄️", go: "bridge" },
    { id: "news", label: "Actualités", ico: "📰", go: "news" },
    { id: "bibli", label: "Bibliothèque", ico: "📚", go: "explorer", q: "" },
    { id: "jarvis", label: "JARVIS", ico: "🤖", go: "jarvis" },
    { id: "reseau", label: "Réseau", ico: "👥", go: "reseau" },
    { id: "events", label: "Événements", ico: "📅", go: "demo" },
    { id: "plus", label: "Plus", ico: "⋯", go: "plus" }
  ];

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
      } catch (e) {}
    }
  }

  function ensureStyles() {
    if ($("sycam-v230-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v230-css";
    s.textContent = [
      ".v230-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:8px 0 16px}",
      "@media(min-width:480px){.v230-grid{grid-template-columns:repeat(4,1fr)}}",
      "@media(min-width:768px){.v230-grid{grid-template-columns:repeat(6,1fr)}}",
      ".v230-tile{aspect-ratio:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;",
      "background:#f8fafc;border:1px solid #e2e8f0;border-radius:16px;cursor:pointer;padding:10px;color:#0f172a;",
      "box-shadow:0 1px 2px rgba(15,23,42,.04);transition:transform .12s ease,border-color .12s}",
      ".v230-tile:active{transform:scale(.97)}",
      ".v230-tile:hover{border-color:#0d7377}",
      ".v230-tile .ico{font-size:28px;line-height:1}",
      ".v230-tile .lb{font-size:11px;font-weight:700;text-align:center;color:#334155}",
      ".v230-tile.news{background:linear-gradient(145deg,#ecfeff,#f0fdfa);border-color:#99f6e4}",
      ".v230-sec{font-size:13px;font-weight:800;color:#2dd4bf;margin:12px 0 8px}",
      "body.sycam-v219-mobile .v230-tile{background:#111827;border-color:#1f2937;color:#e2e8f0}",
      "body.sycam-v219-mobile .v230-tile .lb{color:#cbd5e1}",
      "body.sycam-v219-mobile .v230-tile.news{background:#0f2a2c;border-color:#0d7377}",
      "#pg-news-v230{padding:12px 14px 100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}",
      "#pg-news-v230.on{display:block}",
      "#pg-news-v230 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v230-filter{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 12px}",
      ".v230-filter button{border:0;border-radius:999px;padding:8px 12px;font-size:12px;font-weight:700;background:#1f2937;color:#e2e8f0;cursor:pointer}",
      ".v230-filter button.on{background:#0d7377;color:#fff}"
    ].join("");
    document.head.appendChild(s);
  }

  function routeShortcut(sc) {
    if (!sc) return;
    if (sc.go === "news") {
      openNews();
      return;
    }
    if (sc.go === "publish" && global.SycamV221) {
      global.SycamV221.openPublish(sc.arg || "article");
      return;
    }
    if (sc.go === "explorer" && global.SycamV220) {
      global.SycamV220.openExplorer(sc.q || "");
      return;
    }
    if (sc.go === "bridge" && global.SycamV211 && global.SycamV211.openBridge) {
      global.SycamV211.openBridge();
      return;
    }
    if (sc.go === "jarvis") {
      if (global.SycamV210 && global.SycamV210.openNexusSoftware) global.SycamV210.openNexusSoftware();
      else if (global.SycamV209 && global.SycamV209.openNexus) global.SycamV209.openNexus();
      return;
    }
    if (sc.go === "reseau" && global.SycamV222) {
      global.SycamV222.openNetwork({});
      return;
    }
    if (sc.go === "mission" && global.SycamV219) {
      global.SycamV219.openMissionControl();
      return;
    }
    if (sc.go === "plus" && global.SycamV228) {
      global.SycamV228.openPlusHub();
      return;
    }
    if (sc.go === "demo" && global.SycamV225) {
      global.SycamV225.openDemo();
      return;
    }
    toast(sc.label);
  }

  function renderShortcutsGrid(host) {
    if (!host) return;
    ensureStyles();
    host.innerHTML =
      '<div class="v230-sec">Raccourcis institutionnels</div>' +
      '<div class="v230-grid">' +
      SHORTCUTS.map(function (sc) {
        return (
          '<button type="button" class="v230-tile' +
          (sc.id === "news" ? " news" : "") +
          '" data-sc="' +
          esc(sc.id) +
          '"><span class="ico">' +
          sc.ico +
          '</span><span class="lb">' +
          esc(sc.label) +
          "</span></button>"
        );
      }).join("") +
      "</div>" +
      '<div class="v230-sec">Activité récente</div>' +
      '<div id="v230Recent" class="v230-recent"></div>';

    host.querySelectorAll("[data-sc]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-sc");
        var sc = SHORTCUTS.filter(function (x) {
          return x.id === id;
        })[0];
        routeShortcut(sc);
      };
    });

    // light recent publications only (not news dump)
    var recent = $("v230Recent");
    if (recent && global.SycamV220 && global.SycamV220.buildFeed) {
      recent.innerHTML = '<div style="font-size:12px;color:#94a3b8">Chargement…</div>';
      global.SycamV220.buildFeed({ withHal: false }).then(function (items) {
        items = (items || []).filter(function (i) {
          return i.kind === "pub" || i.tag === "Pub" || i.tag === "Note";
        });
        if (!items.length) {
          recent.innerHTML =
            '<div style="font-size:12px;color:#94a3b8;padding:12px 0">Aucune publication locale. Utilisez <b>+ Publier</b>.</div>';
          return;
        }
        recent.innerHTML = items
          .slice(0, 5)
          .map(function (i) {
            return (
              '<article class="v219-feed-card" style="margin-bottom:8px"><span class="tag">' +
              esc(i.tag) +
              "</span><h4>" +
              esc(i.title) +
              '</h4><div class="meta">' +
              esc(i.meta) +
              "</div></article>"
            );
          })
          .join("");
      });
    }
  }

  function injectHomeLayout() {
    var home = $("pg-mobilehome");
    if (!home || home.style.display === "none") return;
    ensureStyles();

    // Remove / hide heavy news feed from home
    var feed = $("v219Feed") || $("v220Feed");
    if (feed) {
      feed.innerHTML = "";
      feed.style.display = "none";
    }
    // Hide chips that were for news filtering on home
    home.querySelectorAll(".v219-chip-row").forEach(function (row) {
      row.style.display = "none";
    });

    var host = $("v230Shortcuts");
    if (!host) {
      host = document.createElement("div");
      host.id = "v230Shortcuts";
      // place after stories bar or after subtitle
      var stories = $("v223StoriesBar");
      var search = $("v219Search");
      if (stories && stories.parentNode) {
        stories.parentNode.insertBefore(host, stories.nextSibling);
      } else if (search && search.parentNode) {
        search.parentNode.insertBefore(host, search.nextSibling);
      } else {
        home.appendChild(host);
      }
    }
    renderShortcutsGrid(host);
  }

  function showPage(id) {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  async function openNews(filter) {
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    filter = filter || "all";
    var page = showPage("pg-news-v230");
    page.innerHTML =
      "<h1>Actualités</h1>" +
      '<p style="font-size:12px;color:#94a3b8;margin:0 0 8px">Veille scientifique · HAL · sources partenaires</p>' +
      '<div class="v230-filter">' +
      '<button type="button" class="' +
      (filter === "all" ? "on" : "") +
      '" data-nf="all">Tout</button>' +
      '<button type="button" class="' +
      (filter === "hal" ? "on" : "") +
      '" data-nf="hal">HAL</button>' +
      '<button type="button" class="' +
      (filter === "sycam" ? "on" : "") +
      '" data-nf="sycam">SYCAM</button>' +
      "</div>" +
      '<div id="v230NewsList"><div style="color:#2dd4bf;font-size:13px">Chargement…</div></div>' +
      '<div style="margin-top:12px"><button type="button" id="v230BackHome" style="border:0;border-radius:10px;padding:12px 14px;background:#1f2937;color:#fff;font-weight:700">← Accueil</button></div>';

    page.querySelectorAll("[data-nf]").forEach(function (b) {
      b.onclick = function () {
        openNews(b.getAttribute("data-nf"));
      };
    });
    $("v230BackHome").onclick = function () {
      if (global.SycamV219) global.SycamV219.openMobileHome();
    };

    var list = $("v230NewsList");
    var items = [];
    if (global.SycamV220 && global.SycamV220.buildFeed) {
      items = await global.SycamV220.buildFeed({ withHal: true, q: "Afrique science" });
      items = (items || []).filter(function (i) {
        return i.kind === "news" || i.tag === "HAL" || i.tag === "News";
      });
    }
    if (filter === "hal") {
      items = items.filter(function (i) {
        return i.tag === "HAL";
      });
    }
    if (filter === "sycam") {
      items = items.filter(function (i) {
        return i.tag !== "HAL";
      });
    }
    if (!items.length) {
      list.innerHTML =
        '<div style="padding:24px;text-align:center;color:#94a3b8;font-size:13px">Aucune actualité pour le moment.<br/>Vérifiez le réseau ou réessayez plus tard.</div>';
      return;
    }
    list.innerHTML = items
      .slice(0, 40)
      .map(function (i) {
        return (
          '<article class="v219-feed-card" style="margin-bottom:10px"><span class="tag">' +
          esc(i.tag) +
          "</span><h4>" +
          esc(i.title) +
          '</h4><div class="meta">' +
          esc(i.meta) +
          '</div><div class="excerpt">' +
          esc(i.excerpt || "") +
          "</div>" +
          (i.url
            ? '<div style="margin-top:8px"><a href="' +
              esc(i.url) +
              '" target="_blank" rel="noopener" style="font-size:12px;font-weight:700;color:#0d7377">Ouvrir</a></div>'
            : "") +
          "</article>"
        );
      })
      .join("");
  }

  function patchHome() {
    if (!global.SycamV219 || !global.SycamV219.openMobileHome) return;
    if (global.SycamV219.__v230) return;
    var orig = global.SycamV219.openMobileHome.bind(global.SycamV219);
    global.SycamV219.openMobileHome = function () {
      orig();
      setTimeout(injectHomeLayout, 80);
    };
    global.SycamV219.__v230 = true;
  }

  function boot() {
    ensureStyles();
    patchHome();
    setTimeout(patchHome, 400);
    setTimeout(injectHomeLayout, 700);

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v230"] = {
        id: "sycam-v230",
        version: VERSION,
        global: "SycamV230",
        requires: ["sycam-v229"],
        provides: ["home.shortcuts", "news.page"],
        modifies: ["SycamV219.openMobileHome"],
        routes: ["news", "actualites"],
        storage: [],
        events: [],
        permissions: ["ui.home"],
        adr: ["ADR-032"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV230 = ["SycamV229"];
    }
    if (typeof global.go === "function" && !global.__sycamV230Go) {
      global.__sycamV230Go = true;
      var origGo = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "news" || n === "actualites") {
          openNews();
          return;
        }
        return origGo.apply(this, arguments);
      };
    }
    console.log("[V230] Home shortcuts + news page", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV230 = {
    version: VERSION,
    openNews: openNews,
    injectHomeLayout: injectHomeLayout,
    SHORTCUTS: SHORTCUTS
  };
})(typeof window !== "undefined" ? window : this);
