/*! SYCAM V235 — Explorer pro (découverte profonde)
 * Types · filtres · résultats · actions (ouvrir, sauver, citer, JARVIS)
 */
(function (global) {
  "use strict";

  var VERSION = "235.0.0-explorer-pro";
  var SAVED_KEY = "sycam_explorer_saved_v235";

  var TYPES = [
    { id: "all", label: "Tout", ico: "🔎" },
    { id: "article", label: "Articles", ico: "📄" },
    { id: "these", label: "Thèses", ico: "🎓" },
    { id: "dataset", label: "Datasets", ico: "📊" },
    { id: "theme", label: "Thèmes", ico: "🏷️" },
    { id: "projet", label: "Projets", ico: "💼" },
    { id: "donnee", label: "Données", ico: "🗄️" },
    { id: "video", label: "Vidéos", ico: "▶️" },
    { id: "event", label: "Événements", ico: "📅" },
    { id: "lab", label: "Labos", ico: "🧪" }
  ];

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") global.showToast(msg);
  }
  function load(k, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(k) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {}
  }

  function ensureStyles() {
    if ($("sycam-v235-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v235-css";
    s.textContent = [
      "#pg-explorer-v235{padding:12px 14px 110px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}",
      "#pg-explorer-v235.on{display:block}",
      "#pg-explorer-v235 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v235-sub{font-size:12px;color:#94a3b8;margin:0 0 12px}",
      ".v235-search{display:flex;gap:8px;margin-bottom:12px}",
      ".v235-search input{flex:1;border:1px solid #1f2937;border-radius:12px;padding:12px 14px;background:#111827;color:#fff;font-size:15px;min-height:48px}",
      ".v235-search button{border:0;border-radius:12px;padding:0 16px;background:#0d7377;color:#fff;font-weight:800;cursor:pointer}",
      ".v235-types{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:0 0 14px}",
      "@media(min-width:480px){.v235-types{grid-template-columns:repeat(5,1fr)}}",
      ".v235-type{aspect-ratio:1.1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:#111827;border:1px solid #1f2937;border-radius:14px;cursor:pointer;color:#e2e8f0;font-size:11px;font-weight:700}",
      ".v235-type.on{border-color:#0d7377;background:#0f2a2c;color:#2dd4bf}",
      ".v235-type .ico{font-size:22px}",
      ".v235-filters{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px}",
      ".v235-filters select,.v235-filters button{border:1px solid #1f2937;border-radius:999px;padding:8px 12px;background:#111827;color:#cbd5e1;font-size:11px;font-weight:700}",
      ".v235-card{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:14px;margin:0 0 10px}",
      ".v235-card .kind{font-size:10px;font-weight:800;color:#2dd4bf;text-transform:uppercase}",
      ".v235-card h3{margin:6px 0 4px;font-size:15px;color:#fff;line-height:1.3}",
      ".v235-card .meta{font-size:11px;color:#94a3b8}",
      ".v235-card .stats{font-size:11px;color:#64748b;margin-top:6px}",
      ".v235-card .acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}",
      ".v235-card .acts button{border:0;border-radius:8px;padding:8px 10px;font-size:11px;font-weight:700;background:#1f2937;color:#e2e8f0;cursor:pointer}",
      ".v235-card .acts button.p{background:#0d7377;color:#fff}",
      ".v235-empty{text-align:center;padding:28px 12px;color:#94a3b8;font-size:13px}"
    ].join("");
    document.head.appendChild(s);
  }

  function showPage() {
    ensureStyles();
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $("pg-explorer-v235");
    if (!page) {
      page = document.createElement("section");
      page.id = "pg-explorer-v235";
      page.className = "page";
      (document.getElementById("app-main") || document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    try {
      document.querySelectorAll(".sycam-v219-bottom-nav button").forEach(function (b) {
        b.classList.toggle("on", b.getAttribute("data-nav") === "explorer");
      });
    } catch (e) {}
    return page;
  }

  async function collectResults(q, type) {
    q = String(q || "").trim();
    var out = [];

    // Local publications
    try {
      var res = global.SycamV210 && global.SycamV210.listResources ? global.SycamV210.listResources() : [];
      res.forEach(function (r) {
        var title = r.title || "Document";
        if (q && title.toLowerCase().indexOf(q.toLowerCase()) < 0) return;
        var t = (r.type || "article").toLowerCase();
        if (type !== "all") {
          if (type === "article" && t.indexOf("pub") < 0 && t.indexOf("article") < 0 && t.indexOf("document") < 0) return;
          if (type === "dataset" && t.indexOf("data") < 0) return;
          if (type === "these" && t.indexOf("these") < 0 && t.indexOf("thèse") < 0) return;
        }
        out.push({
          id: r.id,
          kind: "Local · " + (r.type || "doc"),
          title: title,
          meta: (r.source || "sycam") + " · " + (r.createdAt || "").slice(0, 10),
          url: null,
          source: "local",
          raw: r
        });
      });
    } catch (e) {}

    // HAL
    if (type === "all" || type === "article" || type === "these" || type === "dataset") {
      try {
        var pack = null;
        if (global.SycamV232 && global.SycamV232.searchHal) {
          pack = await global.SycamV232.searchHal(q || "science Afrique", "", 15);
        } else if (global.SycamV202 && global.SycamV202.searchHal) {
          pack = await global.SycamV202.searchHal(q || "science Afrique", "", 15);
        }
        (pack && pack.docs ? pack.docs : []).forEach(function (d) {
          out.push({
            id: d.halId || d.uri,
            kind: "HAL · Article",
            title: d.title,
            meta: (d.authors || []).slice(0, 2).join(", ") + (d.producedDate ? " · " + d.producedDate : ""),
            url: d.uri,
            source: "hal",
            stats: "source ouverte",
            raw: d
          });
        });
      } catch (e) {}
    }

    // Challenges as projects/events
    if (type === "all" || type === "projet" || type === "event") {
      try {
        var ch = global.SycamV234 && global.SycamV234.getChallenges ? global.SycamV234.getChallenges() : [];
        ch.forEach(function (c) {
          if (q && (c.title + c.excerpt).toLowerCase().indexOf(q.toLowerCase()) < 0) return;
          out.push({
            id: c.id,
            kind: "Challenge · " + c.mode,
            title: c.title,
            meta: c.org + " · " + (c.days ? c.days + " j" : "clos"),
            url: null,
            source: "challenge",
            raw: c
          });
        });
      } catch (e) {}
    }

    return out;
  }

  function saveItem(item) {
    var list = load(SAVED_KEY, []);
    list.unshift({ at: new Date().toISOString(), item: item });
    save(SAVED_KEY, list.slice(0, 100));
    toast("Enregistré dans Bibliothèque locale");
  }

  function citeItem(item) {
    var text = item.title + (item.meta ? " — " + item.meta : "") + (item.url ? " " + item.url : "");
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        toast("Citation copiée");
      });
    } else {
      toast(text.slice(0, 80));
    }
  }

  function openExplorer(q0, type0) {
    var page = showPage();
    var state = { q: q0 || "", type: type0 || "all" };

    function paint() {
      page.innerHTML =
        "<h1>Explorer</h1>" +
        '<p class="v235-sub">Recherche globale · publications · projets · HAL</p>' +
        '<div class="v235-search"><input id="v235q" type="search" placeholder="Rechercher dans SYCAM-PUB…" value="' +
        esc(state.q) +
        '"/><button type="button" id="v235go">OK</button></div>' +
        '<div class="v235-types" id="v235types">' +
        TYPES.map(function (t) {
          return (
            '<button type="button" class="v235-type' +
            (state.type === t.id ? " on" : "") +
            '" data-type="' +
            t.id +
            '"><span class="ico">' +
            t.ico +
            "</span>" +
            esc(t.label) +
            "</button>"
          );
        }).join("") +
        "</div>" +
        '<div class="v235-filters">' +
        '<select id="v235sort"><option value="rel">Pertinence</option><option value="date">Plus récents</option></select>' +
        '<button type="button" id="v235saved">Mes enregistrés</button>' +
        "</div>" +
        '<div id="v235results"><div class="v235-empty">Recherche en cours…</div></div>';

      $("v235go").onclick = function () {
        state.q = $("v235q").value;
        run();
      };
      $("v235q").onkeydown = function (e) {
        if (e.key === "Enter") {
          state.q = $("v235q").value;
          run();
        }
      };
      page.querySelectorAll("[data-type]").forEach(function (b) {
        b.onclick = function () {
          state.type = b.getAttribute("data-type");
          paint();
          run();
        };
      });
      $("v235saved").onclick = function () {
        var list = load(SAVED_KEY, []);
        var host = $("v235results");
        if (!list.length) {
          host.innerHTML = '<div class="v235-empty">Aucun document enregistré.</div>';
          return;
        }
        host.innerHTML = list
          .map(function (x) {
            var item = x.item || {};
            return (
              '<article class="v235-card"><div class="kind">Enregistré</div><h3>' +
              esc(item.title) +
              '</h3><div class="meta">' +
              esc(item.meta || "") +
              "</div></article>"
            );
          })
          .join("");
      };
    }

    async function run() {
      var host = $("v235results");
      if (!host) return;
      host.innerHTML = '<div class="v235-empty">Recherche…</div>';
      var items = await collectResults(state.q, state.type);
      if (!items.length) {
        host.innerHTML =
          '<div class="v235-empty">Aucun résultat.<br/>Essayez « Cameroun », « énergie » ou publiez un document.</div>';
        return;
      }
      host.innerHTML = items
        .map(function (item, idx) {
          return (
            '<article class="v235-card" data-idx="' +
            idx +
            '"><div class="kind">' +
            esc(item.kind) +
            "</div><h3>" +
            esc(item.title) +
            '</h3><div class="meta">' +
            esc(item.meta) +
            "</div>" +
            (item.stats ? '<div class="stats">' + esc(item.stats) + "</div>" : "") +
            '<div class="acts">' +
            '<button type="button" class="p" data-act="open">Ouvrir</button>' +
            '<button type="button" data-act="save">Enregistrer</button>' +
            '<button type="button" data-act="cite">Citer</button>' +
            '<button type="button" data-act="share">Partager</button>' +
            '<button type="button" data-act="jarvis">JARVIS</button>' +
            "</div></article>"
          );
        })
        .join("");

      host.querySelectorAll(".v235-card").forEach(function (card) {
        var idx = parseInt(card.getAttribute("data-idx"), 10);
        var item = items[idx];
        card.querySelectorAll("[data-act]").forEach(function (btn) {
          btn.onclick = function () {
            var act = btn.getAttribute("data-act");
            if (act === "open") {
              if (item.url) window.open(item.url, "_blank", "noopener");
              else toast("Document local : " + item.title);
            } else if (act === "save") saveItem(item);
            else if (act === "cite") citeItem(item);
            else if (act === "share") {
              if (navigator.share) {
                navigator.share({ title: item.title, text: item.meta, url: item.url || undefined }).catch(function () {});
              } else citeItem(item);
            } else if (act === "jarvis") {
              toast("JARVIS : analyse « " + item.title.slice(0, 40) + "… »");
              if (global.SycamV210 && global.SycamV210.openNexusSoftware) global.SycamV210.openNexusSoftware();
            }
          };
        });
      });
    }

    paint();
    run();
  }

  function patchNav() {
    // Override V220 explorer + bottom nav
    if (global.SycamV220) {
      global.SycamV220.openExplorer = function (q) {
        openExplorer(q || "", "all");
      };
    }
    document.addEventListener(
      "click",
      function (e) {
        var b = e.target && e.target.closest && e.target.closest(".sycam-v219-bottom-nav [data-nav='explorer']");
        if (!b) return;
        e.preventDefault();
        e.stopPropagation();
        openExplorer("", "all");
      },
      true
    );
  }

  function boot() {
    patchNav();
    setTimeout(patchNav, 400);
    if (typeof global.go === "function" && !global.__sycamV235Go) {
      global.__sycamV235Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "explorer" || n === "search") {
          openExplorer("", "all");
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V235] Explorer pro", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV235 = {
    version: VERSION,
    openExplorer: openExplorer
  };
})(typeof window !== "undefined" ? window : this);
